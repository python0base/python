/** Automatically generated file. DO NOT MODIFY */
package com.neusoft.myapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}