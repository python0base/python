package com.neusoft.myapp;

import java.util.ArrayList;
import java.util.Map;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.service.ItemBiz;
import com.neusoft.myapp.service.ItemBizImpl;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class AdminItemActivity extends Activity {

	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_item_admin);
		ShopDB spDB = new ShopDB(AdminItemActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		
		

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_desc, menu);
		return true;
	}

	

	
}
