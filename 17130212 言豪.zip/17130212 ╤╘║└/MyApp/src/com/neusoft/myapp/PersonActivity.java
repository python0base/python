package com.neusoft.myapp;

import java.io.IOException;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.User;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

public class PersonActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_person);
		ShopDB spDB = new ShopDB(PersonActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�

		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.person, menu);
		return true;
	}

	public void topwd(View v) throws IOException {

		Toast.makeText(this, "�޸�����", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this, PwdActivity.class);
		System.out.println("��ת");
		startActivity(intent);
		System.out.println("��ת1");
		this.finish();// �رյ�ǰActivity
	}

	public void money(View v) throws IOException {

		Toast.makeText(this, "��ֵ", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this, MoneyActivity.class);
		startActivity(intent);
		this.finish();// �رյ�ǰActivity
	} 
	public void address(View v) throws IOException {

		Toast.makeText(this, "�ҵĵ�ַ", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this, AdresssActivity.class);
		startActivity(intent);
		this.finish();// �رյ�ǰActivity
	} 
	public void order(View v) throws IOException {

		Toast.makeText(this, "�ҵĶ���", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this,OrderActivity.class);
		startActivity(intent);
		this.finish();// �رյ�ǰActivity
	} 
	public void tou(View v) throws IOException {

		Toast.makeText(this, "�ҵ�ͷ��", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this,TouActivity.class);
		startActivity(intent);
		this.finish();// �رյ�ǰActivity
	}

}
