package com.neusoft.myapp;

import java.util.ArrayList;
import java.util.Map;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.Address;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.AddressBiz;
import com.neusoft.myapp.service.AddressBizImpl;
import com.neusoft.myapp.service.ItemBiz;
import com.neusoft.myapp.service.ItemBizImpl;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddressDActivity extends Activity {
	
	private EditText editText1,editText2,editText3,
	editText4;
	private Address address = new Address();
	private AddressBiz addressBiz = new AddressBizImpl();//
	private ArrayList<Map<String, Object>> userDatas;

	private UserBiz UserBiz = new UserBizImpl();
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_address_d);
		ShopDB spDB = new ShopDB(AddressDActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
        AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		initCompoment();// ��ʼ�����
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("��ʼ�����");	
	}

	private void initCompoment() {
		editText1 = (EditText) findViewById(R.id.editText11);
		editText2 = (EditText) findViewById(R.id.editText22);
		editText3 = (EditText) findViewById(R.id.editText33);
		editText4 = (EditText) findViewById(R.id.editText44);
	}
	private void init() throws Exception {
		userDatas = AdresssActivity.datas;
		
		AppInfo appInfo = (AppInfo) getApplication();
		
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		user.getUserName();

		editText1.setText(user.getUserName());
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_item, menu);
		return true;
	}
	
	public void add(View v) throws Exception {
		
		System.out.println("����¼�");
		AppInfo appInfo = (AppInfo) getApplication();
		
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		user.getUserName();
		
		editText1.setText(user.getUserName());
		
		String name = editText1.getText().toString();//����66
		String phone = editText2.getText().toString();//����
		String address1 = editText4.getText().toString();//����
		String flag = editText3.getText().toString();//����
		
		User  users = UserBiz.findUserByName(AddressDActivity.this, name);
		
		
		System.out.println("1111");
		
		
		Address address = new Address();
		address.setUserId(users.getUserId());
		address.setName(name);
		address.setPhone(phone);
		address.setAddress(address1);
		address.setFlag(flag);

		addressBiz.addAddress(AddressDActivity.this, address);
		System.out.println("����");
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
	}
}