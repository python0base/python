package com.neusoft.myapp;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.neusoft.myapp.pojo.Address;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.service.AddressBiz;
import com.neusoft.myapp.service.AddressBizImpl;

import com.neusoft.myapp.db.ShopDB;

public class AdresssActivity extends Activity {

	public static ArrayList<Map<String, Object>> datas;
	private ListView lv11;
	private SimpleAdapter usersAdapter;// �������� ������ListView�Ľ��
	private AddressBiz addressBiz = new AddressBizImpl();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_adresss);
		ShopDB spDB = new ShopDB(AdresssActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		initCompoment();// ��ʼ�����
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void initCompoment() {
		lv11 = (ListView) findViewById(R.id.lv11);

	}

	private void init() throws Exception {
		// 1.��ȡ����
		datas = addressBiz.dealFindAllAddress(AdresssActivity.this);
		System.out.println(""+datas.toArray());
		// 2.������datas��ListView���
		// ��������д ����****************
		usersAdapter = new SimpleAdapter(this, datas, // ��Ҫ����������
														// ����Map<String,Object>
				R.layout.users_style, // ������Ҫ�󶨵�ҳ���ļ�
				new String[] { "name", "phone", "address" }, // map��key������
				new int[] { R.id.tv_name, R.id.tv_birth, R.id.tv_balance,
						 });// ��Ҫ�󶨵�ID��
		lv11.setAdapter(usersAdapter);

		// ���û���lISTview���ӵ���¼�
		lv11.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				Toast.makeText(
						AdresssActivity.this,
						"���λ��" + position + "����"
								+ datas.get(position).get("name").toString(),
						Toast.LENGTH_SHORT).show();
				// ҳ����ת
				Intent intent = new Intent(AdresssActivity.this,
						UpdateAddreActivity.class);
				// ���ݴ���
				intent.putExtra("position", position);// ����ǰ���Ϊ�ô��ݵ�UserDescActivity
				startActivity(intent);
			}
		});
		// ���û���lIstview���ӳ����¼�ʵ���û���ɾ��
		lv11.setOnItemLongClickListener(new OnItemLongClickListener() {

			@Override
			public boolean onItemLongClick(AdapterView<?> parent, View view,
					final int posoition, long id) {
				// Ƕ�׶Ի����ʹ��
				AlertDialog.Builder builder = new AlertDialog.Builder(
						AdresssActivity.this);
				builder.setMessage("ȷ��ɾ��");
				builder.setTitle("��ʾɾ��");
				// ȷ����ť
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						String username = datas.get(posoition).get("name")
								.toString();
						System.out.println("������" + username);
						if (datas.remove(posoition) != null) {
							System.out.println("ɾ���ɹ�");
							try {
								Address address = addressBiz.findAddressByin(
										AdresssActivity.this, username, 1);
								int i = address.getAddressId();
								boolean b = addressBiz.deleteAddress(
										AdresssActivity.this, i);
								System.out.println("ɾ�����" + b);
							} catch (Exception e) {
								e.printStackTrace();
							}
						} else {
							System.out.println("ɾ��ʧ��");
						}
						// ���������ݸ���
						usersAdapter.notifyDataSetChanged();
						// ȡ����ť

					}
				});

				builder.setNegativeButton("ȡ��", new OnClickListener() {

					@Override
					public void onClick(DialogInterface dialog, int which) {

					}
				});
				builder.create().show();
				return false;
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.adresss, menu);
		return true;
	}
	
	
	public void addAddress(View v) throws IOException {
		AppInfo appInfo = (AppInfo) getApplication();
		
		Toast.makeText(this, "����", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this,AddressDActivity .class);
		startActivity(intent);
		
	}
}
