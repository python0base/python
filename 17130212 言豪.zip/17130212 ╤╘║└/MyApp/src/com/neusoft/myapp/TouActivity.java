package com.neusoft.myapp;

import java.io.IOException;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemClickListener;

public class TouActivity extends Activity {
	private EditText editText1;
	private UserBiz userBiz = new UserBizImpl();
	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_tou);
		ShopDB spDB = new ShopDB(TouActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		
		initCompoment();// ��ʼ�����
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}//��ʼ��
		// �Ӷ����AppInfo��ȡ�û���Ϣ
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		if (null != user) {
			user.getUserName() ;
		} else {
		
		}
	}
	private void initCompoment() {
		editText1 = (EditText) findViewById(R.id.editText1);
		
	}
	
	private void init() throws Exception {
		
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		if (null != user) {
			Integer a = user.getUserId();
			String b = "t"+a.toString();
			int img =  TouActivity.this.getResources().getIdentifier(b, "drawable", TouActivity.this.getPackageName());			
			
		}
			
		
		
		
		
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.tou, menu);
		return true;
	}
	
	public void tou(View v) throws IOException {
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		
		try {
			
			
			
			User user1 = userBiz.findUserByName(TouActivity.this, user.getUserName());
			
			
			/*user1.setAA();*/
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Toast.makeText(this, "����ͷ��", Toast.LENGTH_SHORT).show();
		Intent intent = new Intent(this,MainActivity.class);
		startActivity(intent);
		this.finish();// �رյ�ǰActivity
	}

}
