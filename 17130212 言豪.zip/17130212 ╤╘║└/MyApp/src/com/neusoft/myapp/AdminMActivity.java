package com.neusoft.myapp;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Toast;

public class AdminMActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_admin_m);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.admin_m, menu);
		return true;
	}

	public void user(View v) throws Exception {

		Intent intent = new Intent(this, Admin1Activity.class);
		startActivity(intent);
		Toast.makeText(this, "", Toast.LENGTH_SHORT).show();
	}

	public void item(View v) throws Exception {

		Intent intent = new Intent(this, AdminActivity.class);
		startActivity(intent);
		Toast.makeText(this, "", Toast.LENGTH_SHORT).show();

	}

	public void order(View v) throws Exception {

		Intent intent = new Intent(this, OrderMsActivity.class);
		startActivity(intent);
		Toast.makeText(this, "", Toast.LENGTH_SHORT).show();

	}

}
