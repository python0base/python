package com.neusoft.myapp.service;

import java.util.ArrayList;
import java.util.Map;

import android.content.Context;

import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;

public interface OrderBiz {
	
	
	public Orders findOrderById(Context context,Integer  id)throws Exception;
	
	public boolean addOrder(Context context,Orders orders)
			throws Exception;

	/*
	 * ��ѯ���п���״̬������
	 * */
	public ArrayList<Map<String,Object>> dealFindAllOrder(Context context)throws Exception;
}
