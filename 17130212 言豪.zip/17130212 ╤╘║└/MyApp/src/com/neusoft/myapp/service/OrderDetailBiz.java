package com.neusoft.myapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.R.integer;
import android.content.Context;

import com.neusoft.myapp.pojo.OrderDetail;
import com.neusoft.myapp.pojo.User;

public interface OrderDetailBiz {

	public boolean addOrderDetail(Context context,OrderDetail OrderDetail)
			throws Exception;
	/*�����û������û�ҵ���߼�*/
	public ArrayList<Map<String, Object>> findOrderDetailById(Context context,Integer id)
			throws Exception;
	public ArrayList<Map<String, Object>> findAllOrderDetail(Context context) throws Exception;
}
