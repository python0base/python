package com.neusoft.myapp.service;

import java.util.ArrayList;
import java.util.Map;

import com.neusoft.myapp.pojo.Address;


import android.content.Context;


public interface AddressBiz {
	 /** ��ѯ���п���״̬������
		 * */
		public ArrayList<Map<String,Object>> dealFindAllAddress(Context context)throws Exception;
		
		public boolean addAddress(Context context,Address address)
				throws Exception;
		/*
		 * ɾ��ҵ���߼�
		 * */
		public boolean deleteAddress(Context context,int id) throws Exception;
		
		public boolean updateAddress(Context context,Address address,int addressId) throws Exception;

		public Address findAddressByin(Context context,String name,int id)
				throws Exception;
}
