package com.neusoft.myapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.neusoft.myapp.pojo.CartInfo;
import com.neusoft.myapp.pojo.User;

import android.content.Context;

/**
 * �ṩ��Activity���� 
 * @author lenovo
 *
 */
public interface UserBiz {
	/*ע�Ṧ��*/
	public boolean checkRegist(Context context,User user)
			throws Exception;
	/*��¼����ҵ���߼�*/
	public String checkLogin(Context context,User user)
	        throws Exception;
	/*�����û������û�ҵ���߼�*/
	public User findUserByName(Context context,int id)
			throws Exception;
	public User findUserByName(Context context,String name)
			throws Exception;
	/*
	 * ��ѯ���п���״̬������
	 * */
	public ArrayList<Map<String,Object>> dealFindAllUsers(Context context)throws Exception;

	/*
	 * ɾ��ҵ���߼�
	 * */
	public boolean deleteUser(Context context,String name) throws Exception;
	
	public boolean updateUserBalance(Context context,double balance,int userid) throws Exception;
	
	public boolean updateUserPwd(Context context,String  balance,String name) throws Exception;
	
	public boolean updateUserBalance(Context context,double  balance,String name) throws Exception;
	
	public boolean updateUser(Context context,User  user,String name) throws Exception;
	
	public boolean updateUserState(Context context,int  balance,String name) throws Exception;
	//���ﳵlistcartINfoתlist<Map<>>
	public List<Map<String,Object>> cartMaps(List<CartInfo> cart);
}
