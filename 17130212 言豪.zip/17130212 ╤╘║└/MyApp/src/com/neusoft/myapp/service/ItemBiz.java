package com.neusoft.myapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.content.Context;

import com.neusoft.myapp.pojo.CartInfo;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;

public interface ItemBiz {

	
	//�����û������û�ҵ���߼�
	public Item findItemByName(Context context,int id)
			throws Exception;
	
	 /** ��ѯ���п���״̬������
	 * */
	public ArrayList<Map<String,Object>> dealFindAllItem(Context context)throws Exception;

	public boolean addItem(Context context,Item item)
			throws Exception;
	/*
	 * ɾ��ҵ���߼�
	 * */
	public boolean deleteItem(Context context,String name) throws Exception;
	
	public boolean updateItemCount(Context context,int count,int itemid) throws Exception;
	public boolean updateItem(Context context,Item item,int itemid) throws Exception;
	//���ﳵlistcartINfoתlist<Map<>>
		public List<Map<String,Object>> cartMaps(List<CartInfo> cart)  ;
}
