package com.neusoft.myapp.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class ShopDB extends SQLiteOpenHelper{

	public ShopDB(Context context, String name, CursorFactory factory,
			int version) {
		super(context, name, factory, version);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		//�����û���
		db.execSQL("CREATE TABLE IF NOT EXISTS user(USER_ID INTEGER PRIMARY KEY " +
				"AUTOINCREMENT,USER_NAME STRING(12),PASSWORD STRING(12)," +
				"BIRTH STRING,BALANCE DOUBLE(7,2),ROLE INTEGER(1)," +
				"SCORE INTEGER(5),SEX STRING(1),STATE INTEGER(1))");
		db.execSQL("INSERT INTO user (USER_NAME,PASSWORD,BIRTH,BALANCE," +
				"ROLE,SCORE,SEX,STATE) VALUES ('admin','admin','',999.00,0,0,'��',1)");
		db.execSQL("INSERT INTO user (USER_NAME,PASSWORD,BIRTH,BALANCE," +
				"ROLE,SCORE,SEX,STATE) VALUES ('liu','123','',999.00,1,0,'��',0)");
		db.execSQL("INSERT INTO user (USER_NAME,PASSWORD,BIRTH,BALANCE," +
				"ROLE,SCORE,SEX,STATE) VALUES ('neu','123','',999.00,1,0,'Ů',1)");
		//��ʱ���û�������ͼƬ�ֶ�
		db.execSQL("INSERT INTO user (USER_NAME,PASSWORD,BIRTH,BALANCE," +
				"ROLE,SCORE,SEX,STATE) VALUES ('p1','123','',5.00,1,0,'Ů',1)");
		//������ַ��
		db.execSQL("CREATE TABLE IF NOT EXISTS address(ADDRESSID INTEGER PRIMARY KEY " +
				"AUTOINCREMENT,USERID INTEGER(12),NAME STRING(12)," +
				"PHONE INT(5),ADDRESS STRING(12),FLAG STRING(12)" +
				")");
		db.execSQL("INSERT INTO address (ADDRESSID,USERID,NAME,PHONE," +
				"ADDRESS,FLAG) VALUES (1,3,'neu','15050533199','����ʡ������','true')");
		//����������
		db.execSQL("CREATE TABLE IF NOT EXISTS orders(ORDERID INTEGER PRIMARY KEY " +
				"AUTOINCREMENT,ORDERTIME STRING(12),USERID INTEGER(12)," +
				"ADDRESSID INTEGER,GETTIME STRING(12),TOTAL DOUBLE(5)" +
				")");
		db.execSQL("INSERT INTO orders (ORDERID,ORDERTIME,USERID,ADDRESSID," +
				"GETTIME,TOTAL) VALUES (123,'2011-1',3,1,'2012',2.0)");
		db.execSQL("INSERT INTO orders (ORDERID,ORDERTIME,USERID,ADDRESSID," +
				"GETTIME,TOTAL) VALUES (124,'2011-1',3,1,'2012',2.0)");
		db.execSQL("INSERT INTO orders (ORDERID,ORDERTIME,USERID,ADDRESSID," +
				"GETTIME,TOTAL) VALUES (125,'2011-1',3,1,'2012',2.0)");
		db.execSQL("INSERT INTO orders (ORDERID,ORDERTIME,USERID,ADDRESSID," +
				"GETTIME,TOTAL) VALUES (126,'2011-1',3,1,'2012',2.0)");
		//�������������
		db.execSQL("CREATE TABLE IF NOT EXISTS orderdetail(ORDERDETAILID INTEGER PRIMARY KEY " +
				"AUTOINCREMENT,ORDERID INTEGER(100),ITEMID INTEGER(12)," +
				"BUYCOUNT INTEGER(12))");
		
		db.execSQL("INSERT INTO orderdetail (ORDERDETAILID,ORDERID,ITEMID,BUYCOUNT" +
				") VALUES (1,123,3,1)");
		db.execSQL("INSERT INTO orderdetail (ORDERDETAILID,ORDERID,ITEMID,BUYCOUNT" +
				") VALUES (2,124,2,1)");
		db.execSQL("INSERT INTO orderdetail (ORDERDETAILID,ORDERID,ITEMID,BUYCOUNT" +
				") VALUES (3,125,1,1)");
		db.execSQL("INSERT INTO orderdetail (ORDERDETAILID,ORDERID,ITEMID,BUYCOUNT" +
				") VALUES (4,126,4,1)");
		//������Ʒ��
		db.execSQL("CREATE TABLE IF NOT EXISTS item(ITEMID INTEGER PRIMARY KEY " +
				"AUTOINCREMENT,ITEMNAME STRING(12),ITEMPRICE DOUBLE(12)," +
				"COUNT INT(5),ITEMDESC STRING(12),ITEMPIC STRING(12)," +
				"ITEMCREATETIME STRING(12))");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('�����̲�','124','50','11','boba','1111')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('��Բ�̲�','1234','505','112','yuyuan','11112')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('��ݮ�����','1235','506','116','caomei','11116')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('�����̲�','1235','506','116','zhenzhu','11116')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('���ɲ�','124','50','11','shao','1111')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('������','124','50','11','chao','1111')");
		db.execSQL("INSERT INTO item (ITEMNAME,ITEMPRICE,COUNT,ITEMDESC," +
				"ITEMPIC,ITEMCREATETIME) VALUES ('���ǲ���','124','50','11','jao','1111')");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}

}
