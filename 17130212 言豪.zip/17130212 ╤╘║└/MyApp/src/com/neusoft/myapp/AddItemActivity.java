package com.neusoft.myapp;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.service.ItemBiz;
import com.neusoft.myapp.service.ItemBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class AddItemActivity extends Activity {
	
	private EditText editText1,editText2,editText3,
	editText4,editText5,editText6;
	private Item item = new Item();
	private ItemBiz itemBiz = new ItemBizImpl();//

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add_item);
		ShopDB spDB = new ShopDB(AddItemActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		initCompoment();// ��ʼ�����
		System.out.println("��ʼ�����");
		
	}

	private void initCompoment() {
		editText1 = (EditText) findViewById(R.id.editText1);
		editText2 = (EditText) findViewById(R.id.editText2);
		editText3 = (EditText) findViewById(R.id.editText3);
		editText4 = (EditText) findViewById(R.id.editText4);
		editText5 = (EditText) findViewById(R.id.editText5);
		editText6 = (EditText) findViewById(R.id.editText6);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.add_item, menu);
		return true;
	}
	
	public void add(View v) throws Exception {
		System.out.println("����¼�");
		String name = editText1.getText().toString();//����
		double price = Double.parseDouble(editText2.getText().toString());//�۸�
		int count =Integer.parseInt(editText3.getText().toString()) ;//���
		String desc = editText4.getText().toString();//��Ʒ����
		String pic = editText5.getText().toString();//��ƷͼƬ
		String date = editText6.getText().toString();//��Ʒ����ʱ��
		System.out.println("1111");
		item.setItemName(name);
		item.setItemPrice(price);
		item.setCount(count);
		item.setItemDesc(desc);
		item.setItemPic(pic);
		item.setItemCreateTime(date);
		
		itemBiz.addItem(AddItemActivity.this, item);
		System.out.println("����");
		Intent intent = new Intent(this, AdminActivity.class);
		startActivity(intent);
		Toast.makeText(this, "", Toast.LENGTH_SHORT).show();

	}

}
