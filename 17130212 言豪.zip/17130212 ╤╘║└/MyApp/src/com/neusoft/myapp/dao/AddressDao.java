package com.neusoft.myapp.dao;

import java.util.List;



import android.content.Context;

import com.neusoft.myapp.pojo.Address;

public interface AddressDao {
	/*
	 * ������Ʒ
	 */
		public boolean addAddress(Address Address) throws Exception;
		
		public List<Address> findAllAddress()throws Exception;
		
		
		public boolean deleteAddress(int addressId) throws Exception;
		
		public boolean updateAddress(Address address,int addressId) throws Exception;

		public Address findAddressByin(String name,int id)
				throws Exception;
}
