package com.neusoft.myapp.dao;

import java.util.List;

import android.R.integer;

import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.pojo.OrderDetail;
import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;

public interface OrderDetailDao {
	

	/*
	 * ���Ӷ�������
	 */
		public boolean addOrderDetail(OrderDetail orderDetail) throws Exception;
		
		/*
		 * �����û��������û�
		 */
			
		public List<OrderDetail> findOrderDetailById(Integer id)throws Exception;
		
		public List<OrderDetail> findAllOrderDetail() throws Exception;
		
}
