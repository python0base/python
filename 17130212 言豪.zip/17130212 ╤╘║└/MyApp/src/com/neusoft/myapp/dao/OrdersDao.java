package com.neusoft.myapp.dao;



import java.util.List;

import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;


public interface OrdersDao {
	/*
	 * ������Ʒ
	 */
		public boolean addOrders(Orders orders) throws Exception;
		public List<Orders> findAllOrders()throws Exception;

		public Orders findOrderById(Integer  id)throws Exception;
}
