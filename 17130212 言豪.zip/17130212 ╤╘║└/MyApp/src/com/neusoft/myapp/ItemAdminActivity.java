package com.neusoft.myapp;

import java.nio.DoubleBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.CartInfo;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.pojo.OrderDetail;
import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.ItemBiz;
import com.neusoft.myapp.service.ItemBizImpl;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ItemAdminActivity extends Activity {

	private UserBiz userBiz = new UserBizImpl();
	private ItemBiz itemBiz = new ItemBizImpl();//

	private ArrayList<Map<String, Object>> userDatas = MainActivity.datas;

	private TextView tv_name;
	private ImageView iv_image;

	private EditText et_name, et_price, et_count, et_desc, et_pic, et_date;

	private String desc, date, itemPic;
	private int stock;// ������������棬�û��˺ţ�ģ����Ʒ��ţ�

	private String itemName;// ģ����Ʒ��
	private double price;// ���ۣ��ܼ�
	private int img;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_item_admin);
		ShopDB spDB = new ShopDB(ItemAdminActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�

		initComponent();
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("data�е�����" + MainActivity.datas.size());
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);
		int itemId = Integer.parseInt(userDatas.get(position).get("itemId")
				.toString());

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user_desc, menu);
		return true;
	}

	private void initComponent() {

		iv_image = (ImageView) findViewById(R.id.iv_image1);
		et_name = (EditText) findViewById(R.id.et_name1);
		et_price = (EditText) findViewById(R.id.et_price1);
		et_count = (EditText) findViewById(R.id.et_count1);
		et_desc = (EditText) findViewById(R.id.et_desc1);
		et_pic = (EditText) findViewById(R.id.et_pic1);
		et_date = (EditText) findViewById(R.id.et_date1);

	}

	private void init() throws Exception {
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);

		userDatas = MainActivity.datas;

		System.out.println(userDatas.get(position).get("itemName"));// ����position��ȡָ��λ�õ���Ϣ
		System.out.println(userDatas.get(position).get("itemPrice"));
		// ����Ϣд��ҳ��

		int itemId = Integer.parseInt(userDatas.get(position).get("itemId")
				.toString());// ģ����Ʒ���

		Item item = itemBiz.findItemByName(ItemAdminActivity.this, itemId);

		String name1 = item.getItemName();
		String price1 = String.valueOf(item.getItemPrice());
		String count1 = String.valueOf(item.getCount());
		String desc1 = item.getItemDesc();
		String pic1 = item.getItemPic();
		String time1 = item.getItemCreateTime();
			
		et_name.setText(name1);
		et_price.setText(price1);
		et_count.setText(count1);
		et_desc.setText(desc1);
		et_pic.setText(pic1);
		et_date.setText(time1);

		itemName = userDatas.get(position).get("itemName").toString();// ģ����Ʒ��
	}

	public void btnListener(View v) throws Exception {
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);
		userDatas = MainActivity.datas;
		int itemId = Integer.parseInt(userDatas.get(position).get("itemId")
				.toString());//
		
		itemName = et_name.getText().toString();
		price = Double.parseDouble(et_price.getText().toString());
		stock = Integer.parseInt(et_count.getText().toString());
		desc = et_desc.getText().toString();
		
		itemPic = et_pic.getText().toString();
		date = et_date.getText().toString();
		
		Item item = itemBiz.findItemByName(ItemAdminActivity.this, itemId);
		
		item.setItemName(itemName);
		item.setItemPrice(price);
		item.setCount(stock);
		item.setItemDesc(desc);
		item.setItemPic(itemPic);
		item.setItemCreateTime(date);
		System.out.println("�۸�" +price );

		boolean a = itemBiz.updateItem(ItemAdminActivity.this, item, itemId);
		System.out.println("" +a );
		Item item1 = itemBiz.findItemByName(ItemAdminActivity.this, itemId);
		String name2 = item1.getItemName();
		String price2 = String.valueOf(item1.getItemPrice());
		String count2 = String.valueOf(item1.getCount());
		String desc2 = item1.getItemDesc();
		String pic2 = item1.getItemPic();
		String time2 = item1.getItemCreateTime();
		
		System.out.println("�۸�" +price2 );
		Toast.makeText(ItemAdminActivity.this, "�޸���Ʒ�ɹ�", Toast.LENGTH_SHORT)
		.show();
		Intent intent1 = new Intent(this, AdminActivity.class);
		startActivity(intent1);
		this.finish();
	}
}
