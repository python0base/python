package com.neusoft.myapp.pojo;

public class OrderDetail {
	/*���������Զ�����
	������ţ���Ҫ��*/

	private int orderDetailId;
	private int orderId;//��Orders�����
	
	private int itemId;//����Ʒ�����
	private int buyCount;//��������
	public OrderDetail() {
		super();
	}
	public OrderDetail(int orderDetailId, int orderId, int itemId, int buyCount) {
		super();
		this.orderDetailId = orderDetailId;
		this.orderId = orderId;
		this.itemId = itemId;
		this.buyCount = buyCount;
	}
	public int getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(int orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getBuyCount() {
		return buyCount;
	}
	public void setBuyCount(int buyCount) {
		this.buyCount = buyCount;
	}
	@Override
	public String toString() {
		return "OrderDetail [orderDetailId=" + orderDetailId + ", orderId="
				+ orderId + ", itemId=" + itemId + ", buyCount=" + buyCount
				+ "]";
	}
	
	
}
