package com.neusoft.myapp.pojo;

public class Address {

	private int addressId;//��ַ���
	private int userId;//�û���� ���û����û����
	private String name;//��ϵ������
	private String phone;//��ϵ�˵绰
	private String address;//�ջ���ַ
	private String flag;//���ڱ��Ĭ��ѡ�е�ַ1Ĭ��
	public Address() {
		super();
	}
	public Address(int addressId, int userId, String name, String phone,
			String address, String flag) {
		super();
		this.addressId = addressId;
		this.userId = userId;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.flag = flag;
	}
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String isFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", userId=" + userId
				+ ", name=" + name + ", phone=" + phone + ", address="
				+ address + ", flag=" + flag + "]";
	}
	
	
}
