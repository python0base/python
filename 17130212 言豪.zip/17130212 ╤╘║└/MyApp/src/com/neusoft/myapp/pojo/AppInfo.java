package com.neusoft.myapp.pojo;

import android.app.Application;

public class AppInfo extends Application {
	
	private double money;//����ֵ
	private User user;//��������Ϣ����
	//�޲ι��췽��
	public AppInfo() {
		super();
	}
	//set get
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	

}
