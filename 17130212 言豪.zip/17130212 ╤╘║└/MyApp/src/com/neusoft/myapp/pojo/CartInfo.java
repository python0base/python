package com.neusoft.myapp.pojo;

public class CartInfo {
	//��ǰҳ�涼��//���ﳵ//���ɹ��ﳵ��ҳ
	private int itemId;//��Ʒ���
	private String itemName;//��Ʒ��
	private int count;//��������
	private double sum;//�����ܼ�
	private int img;//����ͼƬ��
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getSum() {
		return sum;
	}
	public void setSum(double sum) {
		this.sum = sum;
	}
	public int getImg() {
		return img;
	}
	public void setImg(int img) {
		this.img = img;
	}
	@Override
	public String toString() {
		return "CartInfo [itemId=" + itemId + ", itemName=" + itemName
				+ ", count=" + count + ", sum=" + sum + ", img=" + img + "]";
	}
	public CartInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CartInfo(int itemId, String itemName, int count, double sum, int img) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.count = count;
		this.sum = sum;
		this.img = img;
	}

}
