package com.neusoft.myapp.pojo;

public class User {

	private int userId;//USER_ID
	private String userName;//USER_NAME
	private String password;//PASSWORD
	//private String pwd;//PWD
	private String birth;//BIRTH ʹ��SQLite ������ʱʹ��String
	private double balance;//���
	private int role;//��ɫ   0 ����Ա    1��ͨ�û�
	private int score;//����
	private String sex;//�Ա�
	private int state;//״̬  ��ֹ��ɾ�û�      0������   1����
	//shift+alt+s   �޲Ρ��вΡ�set get  ��toString 
	public User() {
		super();
	}
	public User( int userId,String userName, String password, String birth,
			double balance, int role, int score, String sex, int state) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.birth = birth;
		this.balance = balance;
		this.role = role;
		this.score = score;
		this.sex = sex;
		this.state = state;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public int getRole() {
		return role;
	}
	public void setRole(int role) {
		this.role = role;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName
				+ ", password=" + password + ", birth=" + birth + ", balance="
				+ balance + ", role=" + role + ", score=" + score + ", sex="
				+ sex + ", state=" + state + "]";
	}
	
}
