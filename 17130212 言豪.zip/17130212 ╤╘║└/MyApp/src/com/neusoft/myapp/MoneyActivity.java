package com.neusoft.myapp;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MoneyActivity extends Activity {
	private EditText et_money;
	private UserBiz userBiz = new UserBizImpl();
	private TextView balance;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_money);
		ShopDB spDB = new ShopDB(MoneyActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		initCompoment();
		try {
			init();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private void initCompoment() {

		balance= (TextView) findViewById(R.id.balance);
		et_money = (EditText) findViewById(R.id.et_money);

	}
	

	
	
	private void init() throws Exception {
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
	    
	    User user1 =userBiz.findUserByName(MoneyActivity.this, user.getUserName());
		double money = user1.getBalance();
		balance.setText("��"+money+"Ԫ");	
		
		
	}
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.money, menu);
		return true;
	}
	
	public  void money1(View v) {
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		//��ֵ
		double give = Double.parseDouble(et_money.getText().toString());
		try {
			User user1 =userBiz.findUserByName(MoneyActivity.this, user.getUserName());
			double money = user1.getBalance();
			double gold = money+give;
			String name = user1.getUserName();
			userBiz.updateUserBalance(MoneyActivity.this, gold, name);
			Intent intent = new Intent(this, MoneyActivity.class);
			
			startActivity(intent);
			this.finish();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
