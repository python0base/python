package com.neusoft.myapp;

import java.util.ArrayList;
import java.util.Map;

import com.neusoft.myapp.db.ShopDB;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class UserActivity extends Activity {
	private EditText e1, e2, e3;
	private TextView textView1;
	private UserBiz userBiz = new UserBizImpl();

	public static ArrayList<Map<String, Object>> userDatas = Admin1Activity.datas;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user);
		ShopDB spDB = new ShopDB(UserActivity.this, "shop.db", null, 1);
		SQLiteDatabase db = spDB.getWritableDatabase();// ��ȡ��д�����ݿ�
		initCompoment();
		init();
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);
		String userName = userDatas.get(position).get("userName").toString();// ģ����Ʒ��
	}

	private void initCompoment() {
		textView1 = (TextView) findViewById(R.id.textView1);
		e1 = (EditText) findViewById(R.id.e1);
		e2 = (EditText) findViewById(R.id.e2);
		e3 = (EditText) findViewById(R.id.e3);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.user, menu);
		return true;
	}

	private void init() {
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);
		String userName = userDatas.get(position).get("userName").toString();// ģ����Ʒ��

		System.out.println(userDatas.get(position).get("userName"));// ����position��ȡָ��λ�õ���Ϣ
		
		// ����Ϣд��ҳ��

		textView1.setText("�û�����" + userName);

	}

	    public void a(View v)  {
	    	
		Intent intent = getIntent();
		int position = intent.getIntExtra("position", 0);
		String userName = userDatas.get(position).get("userName").toString();// ģ����Ʒ��

		int score = Integer.parseInt(e1.getText().toString());// ����
		double balance = Double.parseDouble(e2.getText().toString());// ���
		int state = Integer.parseInt(e3.getText().toString());// ״̬

		User user;
		try {
			user = userBiz.findUserByName(UserActivity.this, userName);
			user.setState(state);
			user.setBalance(balance);
			user.setScore(score);
			userBiz.updateUser(UserActivity.this, user, userName);
			 User user1 = userBiz.findUserByName(UserActivity.this, userName);
			 user1.getScore();
			System.out.println("����:" +  user1.getScore());
			Toast.makeText(UserActivity.this, "����:" +  user1.getScore()+"����"+user1.getBalance(), Toast.LENGTH_SHORT)
			.show();
			Intent intent1 = new Intent(this, Admin1Activity.class);
			startActivity(intent1);
			this.finish();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	    public void back(View v){
	    	Toast.makeText(UserActivity.this, "��ӭ����Ա���û�����", Toast.LENGTH_SHORT);
	    	Intent intent1 = new Intent(this, Admin1Activity.class);
			startActivity(intent1);
			this.finish();
	    }

}