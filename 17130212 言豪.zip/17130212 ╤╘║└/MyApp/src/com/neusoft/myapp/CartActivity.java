package com.neusoft.myapp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.neusoft.myapp.pojo.Address;
import com.neusoft.myapp.pojo.AppInfo;
import com.neusoft.myapp.pojo.Item;
import com.neusoft.myapp.pojo.OrderDetail;
import com.neusoft.myapp.pojo.Orders;
import com.neusoft.myapp.pojo.User;
import com.neusoft.myapp.service.AddressBiz;
import com.neusoft.myapp.service.AddressBizImpl;
import com.neusoft.myapp.service.ItemBiz;
import com.neusoft.myapp.service.ItemBizImpl;
import com.neusoft.myapp.service.OrderBiz;
import com.neusoft.myapp.service.OrderBizImpl;
import com.neusoft.myapp.service.OrderDetailBizImpl;
import com.neusoft.myapp.service.OrderDetailBiz;
import com.neusoft.myapp.service.UserBiz;
import com.neusoft.myapp.service.UserBizImpl;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

public class CartActivity extends Activity {
	private ArrayList<Map<String, Object>> userDatas;
	private TextView total;// ������Ʒ��Ϣ
	private ListView ll_carts;
	private double allSum;
	
	private ItemBiz itemBiz = new ItemBizImpl();//
	private AddressBiz addressBiz = new AddressBizImpl();
	

	private Item item = new Item();
	private List<Map<String, Object>> cartsMap;

	private SimpleAdapter cartAdapter;
	private UserBiz userBiz = new UserBizImpl();
	private OrderBiz orderBiz = new OrderBizImpl();
	private OrderDetailBiz orderDetailBiz = new OrderDetailBizImpl();
	private Orders orders = new Orders();// ���ڱ����û���Ϣ
	private OrderDetail orderDetail = new OrderDetail();// ���ڱ����û���Ϣ

	private void initCompoment() {
		total = (TextView) findViewById(R.id.total);
		ll_carts = (ListView) findViewById(R.id.ll_carts);
	}

	private void init() {

		// 1.listview��ʾ
		cartsMap = userBiz.cartMaps(MainActivity.carts);
		cartAdapter = new SimpleAdapter(this, cartsMap, R.layout.cart_style,
				new String[] { "itemId", "itemName", "count", "sum", "img" },
				new int[] { R.id.tv_itemId, R.id.tv_itemName, R.id.tv_count,
						R.id.tv_sum, R.id.iv_image });
		ll_carts.setAdapter(cartAdapter);

		// 2.�ܼ۱��
		for (int i = 0; i < MainActivity.carts.size(); i++) {
			allSum += MainActivity.carts.get(i).getSum();
			total.setText("�ܼ�" + allSum + "Ԫ");
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_cart);
		initCompoment();
		init();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.cart, menu);
		return true;
	}

	// ����

	public void tobuy(View v) throws Exception {
		AppInfo appInfo = (AppInfo) getApplication();
		User user = appInfo.getUser();// AppInfo�б�����û���Ϣ
		int userId = user.getUserId();

		User user1 = userBiz.findUserByName(CartActivity.this, userId);
		double balance = user1.getBalance();
		double c = balance - allSum;
		
			
			
			
			
			
			int orderId = (int)((Math.random()*9+1)*10000);
			
			// new Date()Ϊ��ȡ��ǰϵͳʱ��
			SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm");// �������ڸ�ʽ
			System.out.println(df.format(new Date()));
			String orderTime = df.format(new Date());
			String getTime = df.format(new Date());// �ջ�ʱ��
			User usera=userBiz.findUserByName(CartActivity.this, userId);
			
			Address address = addressBiz.findAddressByin(CartActivity.this, usera.getUserName(), userId);
			
			int address1 = address.getAddressId();
			orders.setOrderId(orderId);
			orders.setUserId(userId);
			orders.setOrderTime(orderTime);
			orders.setGetTime(getTime);
			orders.setTotal(allSum);
			orders.setAddressId(address1);
			
			
			// �޸����
			orderBiz.addOrder(CartActivity.this, orders);
			orders.getOrderId();
			
			try {
				boolean b = userBiz.updateUserBalance(CartActivity.this, c,
						userId);
			} catch (Exception e) {
				e.printStackTrace();
			}

			for (int i = 0; i < MainActivity.carts.size(); i++) {
				int itemId = MainActivity.carts.get(i).getItemId();
				int count1 = MainActivity.carts.get(i).getCount();
				userDatas = MainActivity.datas;
				orderDetail.setOrderId(orderId);
				orderDetail.setItemId(itemId);
				orderDetail.setBuyCount(count1);
				orderDetailBiz.addOrderDetail(CartActivity.this, orderDetail);

				
				System.out.println("�����ţ�" + orderId);
				
				item = itemBiz.findItemByName(CartActivity.this, itemId);
				int count = item.getCount();
				int c1 = count - count1;
				System.out.println("ԭ������" + count);
				System.out.println("���п������" + c1);
				try {
					boolean b = itemBiz.updateItemCount(CartActivity.this, c1,
							itemId);
				} catch (Exception e) {
					e.printStackTrace();
				}

				item = itemBiz.findItemByName(CartActivity.this, itemId);
				int count2 = item.getCount();
				System.out.println("���п������2:" + count2);
			}
			
			Toast.makeText(CartActivity.this, "����ɹ�" + "�������" + orders.getOrderId()+"��ַ��" +address.getAddress(),
					Toast.LENGTH_SHORT).show();
			System.out.println("order�������" + orders.getOrderId());
			System.out.println("detail�������" + orderDetail.getOrderId());
			// ��չ��ﳵ
			MainActivity.carts.clear();

			Intent intent = new Intent(this, MainActivity.class);
			startActivity(intent);

			this.finish();// �رյ�ǰActivity
		}

	}


