package com.neuedu.office03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Office03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
