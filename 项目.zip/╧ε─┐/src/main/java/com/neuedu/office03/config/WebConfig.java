package com.neuedu.office03.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

import com.neuedu.office03.component.DateConverter;
import com.neuedu.office03.component.LoginInterceptor;
@Configuration
public class WebConfig  extends WebMvcConfigurationSupport{
@Autowired
private DateConverter dateConvter;
@Autowired
private LoginInterceptor loginInterceptor;

@Override
protected void addFormatters(FormatterRegistry registry) {
	// TODO Auto-generated method stub
	registry.addConverter(dateConvter);
}

@Override
protected void addResourceHandlers(ResourceHandlerRegistry registry) {
	// TODO Auto-generated method stub
	registry.addResourceHandler("/**")
	.addResourceLocations("classpath:/static/")
	.addResourceLocations("classpath:/public/")
	.addResourceLocations("classpath:/resources/")
	.addResourceLocations("classpath:/META-INF/resources/");
	super.addResourceHandlers(registry);
}

//
@Override
protected void addInterceptors(InterceptorRegistry registry) {
	registry.addInterceptor(loginInterceptor).addPathPatterns("/**")//拦截所有请求
		.excludePathPatterns("/css/**","/images/**","/js/**","/login","/checklogin","/login1");//例外
	//目前好像正常，如果发现druid和Swagger不能使用，例外中请添加"/swagger-ui.html/**","/v2/**","/swagger-resources/**","/druid/**"
	super.addInterceptors(registry);
}

}
