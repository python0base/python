package com.neuedu.office03.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;

import com.neuedu.office03.bll.impl.EmployeeBLL;

import com.neuedu.office03.model.Employee;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(tags = "入职信息控制器")
@Controller
public class EmployeeController {
	@Autowired
	private EmployeeBLL employeeBLL;
	
	@GetMapping(value = {"/employee/managerEmployee"})
	public String managerEmployee(Model model) {
		//查询所有部门信息
		List<Employee> employee = employeeBLL.selectAll();
		//准备统一返回数据类型的对象
		ResultBean<List<Employee>> resultBean = new ResultBean<List<Employee>>(200, true, "查询所有入职信息成功", employee);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		model.addAttribute("office1",resultBean);
		return "/employee/managerEmployee";
	}
	
	
	@ApiOperation(value = "根据入职编号、入职名称、入职类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "id",value = "部门编号",required = false,dataType = "Integer",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "name",value = "部门名称",required = false,dataType = "String",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "form",value = "部门类型",required = false,dataType = "Integer",defaultValue = "")
	})
	@GetMapping(value = {"/employee/selectbylike"})
	public String selectbylike(Integer id,String name,Integer form,Model model) {
		//多条件组合模糊查询
		List<Employee> employee = employeeBLL.selectByLike(id, name, form);
		//准备统一返回数据类型的对象
		ResultBean<List<Employee>> resultBean = new ResultBean<List<Employee>>(200, true, "查询所有员工入职信息成功", employee);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/employee/managerEmployee";
	}
	
	/**
	 * 返回增加部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"employee/createEmployee"})
	public String createEmployee() {
		return "/employee/createEmployee";
	}
	
	/**
	 * 返回修改部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"employee/updataEmployee"})
	public String updataEmployee(Integer id, Model model) {
		Employee employee = employeeBLL.selectById(id);
		ResultBean<Employee> resultBean = new ResultBean<Employee>(200, true, "查询员工入职信息成功",employee);
		//传递部门实体信息数据
		model.addAttribute("rdata", resultBean);
		return "/employee/updataEmployee";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat  dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
	
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	/**
	 * 返回增加/修改的结果JSON
	 * @param id
	 * @param name
	 * @param type
	 * @param telephone
	 * @param fax
	 * @param description
	 * @param predepartment
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	
	
	@ApiOperation(value = "员工入职部门信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "employee",value = "入职信息实体对象",required = true)
	})

	@PostMapping(value = {"employee/save"})
	@ResponseBody
	public ResultBean<String> save(Employee employee) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		
			//增加部门
			if (employeeBLL.insert(employee)) {
				resultBean.setCode(200);
				resultBean.setMessage("增加入职员工信息成功！新增的入职员工编号是" + employee.getId());//获取自动增长列的值
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("增加入职员工信息失败！");
			}
		
		return resultBean;
	}
	
	
	@ApiOperation(value = "入职员工信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "employee",value = "入职员工信息实体对象",required = true)
	})

	@PostMapping(value = {"employee/save2"})
	@ResponseBody
	public ResultBean<String> save2(Employee employee) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
			//修改部门
		
		  if (employeeBLL.update(employee)) { resultBean.setCode(200);
		  resultBean.setMessage("修改部门信息成功！"); }else { resultBean.setCode(500);
		  resultBean.setMessage("修改部门信息失败！"); }
		 
		return resultBean;
	}
	@PostMapping(value = {"employee/batchdelete"})
	@ResponseBody
	public ResultBean<String> batchdelete(@RequestParam("ids[]")Integer[] ids) {
		boolean flag = employeeBLL.batchDelete(ids);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("入职员工信息删除成功~~~");
		}else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("入职员工信息删除失败~~~");
		}
		return resultBean;
	}
}