package com.neuedu.office03.model;

import java.io.Serializable;

public class Post  implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3382770889377335184L;
	private Integer id;

    private String name;

	private String type;

    private Integer number;
    
    
    public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public Post(String name, String type, Integer number) {
		super();
		this.name = name;
		this.type = type;
		this.number = number;
	}

	public Post(Integer id, String name, String type, Integer number) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.number = number;
	}

	public Post() {
		super();
	}

	@Override
	public String toString() {
		 StringBuilder sb = new StringBuilder();
	        sb.append(getClass().getSimpleName());
	        sb.append(" [");
	        sb.append("Hash = ").append(hashCode());
	        sb.append(", id=").append(id);
	        sb.append(", name=").append(name);
	        sb.append(", type=").append(type);
	        sb.append(", number=").append(number);
	        sb.append(", serialVersionUID=").append(serialVersionUID);
	        sb.append("]");
	        return sb.toString();
	}
	
	
	
}
