package com.neuedu.office03.dao;

import com.neuedu.office03.model.Department;
import com.neuedu.office03.model.Management;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.type.JdbcType;

/**
 * 部门信息Mybatis Mapper接口：针对数据库中表department的操作行为定义
 *
 */
@Mapper
public interface ManagementMapper {
	
	@Select("select  count(*)  from management  where  name = #{name}   and password = #{password}")
	int login(@Param("name")String name,@Param("password")String password);
	
    @Delete({
        "delete from management",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into management (id, password, ",
        "name)",
        "values (#{id,jdbcType=INTEGER}, #{password,jdbcType=VARCHAR}, ",
        "#{name,jdbcType=VARCHAR})"
    })
    int insert(Management record);

    @InsertProvider(type=ManagementSqlProvider.class, method="insertSelective")
    int insertSelective(Management record);

    @Select({
        "select",
        "id, password, name",
        "from management",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="password", property="password", jdbcType=JdbcType.VARCHAR),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR)
    })
    Management selectByPrimaryKey(Integer id);

    @UpdateProvider(type=ManagementSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Management record);

    @Update({
        "update management",
        "set password = #{password,jdbcType=VARCHAR},",
          "name = #{name,jdbcType=VARCHAR}",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(Management record);
}


