package com.neuedu.office03.bll.impl;

import java.util.List;


import com.neuedu.office03.model.Employee;

public interface EmployeeBLL {

	List<Employee> selectAll();
	List<Employee> selectByLike(Integer id,String name,Integer form);
	boolean insert(Employee employee);
	boolean update(Employee employee);
	Employee selectById(Integer id);
	
	boolean batchDelete(Integer[] ids);
}
