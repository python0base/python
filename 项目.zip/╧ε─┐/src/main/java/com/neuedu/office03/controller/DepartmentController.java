package com.neuedu.office03.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;
import com.neuedu.office03.bll.impl.DepartmentBLL;
import com.neuedu.office03.model.Department;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiImplicitParam;

@Api(tags = "部门信息控制器")
@Controller
public class DepartmentController {
	@Autowired
	private DepartmentBLL departmentBLL;
	
	@GetMapping(value = {"/department/managerDepartments"})
	public String managerDepartments(Model model) {
		//查询所有部门信息
		List<Department> departments = departmentBLL.selectAll();
		//准备统一返回数据类型的对象
		ResultBean<List<Department>> resultBean = new ResultBean<List<Department>>(200, true, "查询所有部门信息成功", departments);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		
		return "/department/managerDepartments";
	}
	
	@GetMapping(value = {"welcome"})
	public String managerDepartment(Model model) {
		//查询所有部门信息
		List<Department> departments = departmentBLL.selectAll();
		//准备统一返回数据类型的对象
		ResultBean<List<Department>> resultBean = new ResultBean<List<Department>>(200, true, "查询所有部门信息成功", departments);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		
		return "/department/welcome";
	}
	
	@ApiOperation(value = "根据部门编号、部门名称、部门类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "id",value = "部门编号",required = false,dataType = "Integer",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "name",value = "部门名称",required = false,dataType = "String",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "type",value = "部门类型",required = false,dataType = "String",defaultValue = "")
	})
	@GetMapping(value = {"/department/selectbylike"})
	public String selectbylike(Integer id,String name,String type,Model model) {
		//多条件组合模糊查询
		List<Department> departments = departmentBLL.selectByLike(id, name, type);
		//准备统一返回数据类型的对象
		ResultBean<List<Department>> resultBean = new ResultBean<List<Department>>(200, true, "查询所有部门信息成功", departments);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/department/managerDepartments";
	}
	
	/**
	 * 返回增加部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"department/createDepartment"})
	public String createDepartment() {
		return "/department/createDepartment";
	}
	
	/**
	 * 返回修改部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"department/updataDepartment"})
	public String updataDepartment(Integer id, Model model) {
		Department department = departmentBLL.selectById(id);
		ResultBean<Department> resultBean = new ResultBean<Department>(200, true, "查询部门信息成功",department);
		//传递部门实体信息数据
		model.addAttribute("rdata", resultBean);
		return "/department/updataDepartment";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat  dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
	
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	/**
	 * 返回增加/修改的结果JSON
	 * @param id
	 * @param name
	 * @param type
	 * @param telephone
	 * @param fax
	 * @param description
	 * @param predepartment
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	
	
	@ApiOperation(value = "部门信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "department",value = "部门信息实体对象",required = true)
	})

	@PostMapping(value = {"department/save"})
	@ResponseBody
	public ResultBean<String> save(Department department) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (null == department.getId()) {
			//增加部门
			if (departmentBLL.insert(department)) {
				resultBean.setCode(200);
				resultBean.setMessage("增加部门信息成功！新增的部门编号是" + department.getId());//获取自动增长列的值
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("增加部门信息失败！");
			}
		}	else {
			//修改部门
			if (departmentBLL.update(department)) {
				resultBean.setCode(200);
				resultBean.setMessage("修改部门信息成功！");
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("修改部门信息失败！");
			}
		}
		return resultBean;
	}
	
	
	@PostMapping(value = {"department/batchdelete"})
	@ResponseBody
	public ResultBean<String> batchdelete(@RequestParam("ids[]")Integer[] ids) {
		boolean flag = departmentBLL.batchDelete(ids);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("部门信息删除成功~~~");
		}else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("部门信息删除失败~~~");
		}
		return resultBean;
	}
	
	@GetMapping(value = {"department/filedownload"})
	public String fd() {
		return "/department/filedownload";
	}
	
	@GetMapping("department/downLoad")

	private void downloadFile(HttpServletResponse response)  throws IOException{
InputStream f= this.getClass().getResourceAsStream("/static/images/bg.jpg");
		
		response.reset();
        response.setContentType("application/x-msdownload;charset=utf-8");
        try {
            response.setHeader("Content-Disposition", "attachment;filename="+ new String(("bg" + ".jpg").getBytes("gbk"), "iso-8859-1"));//下载文件的名称
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        ServletOutputStream sout = response.getOutputStream();
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            bis = new BufferedInputStream(f);
            bos = new BufferedOutputStream(sout);
            byte[] buff = new byte[2048];
            int bytesRead;
            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                bos.write(buff, 0, bytesRead);
            }
            bos.flush();
            bos.close();
            bis.close();
        } catch (final IOException e) {
            throw e;
        } finally {
            if (bis != null){
            	bis.close();
            }
            if (bos != null){
            	bos.close();
            }
        }
	}

	
}

