package com.neuedu.office03.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.format.FormatterRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.neuedu.office03.component.DateConverter;
import com.neuedu.office03.component.LoginInterceptor;

@SpringBootConfiguration
public class WebMvcConfig extends WebMvcConfigurationSupport{
	@Autowired
	private DateConverter dateConverter;
	@Autowired
	private LoginInterceptor loginInterceptor;

	@Override
	protected void addFormatters(FormatterRegistry registry) {
		registry.addConverter(dateConverter);
	}

	/**
	 * 如果继承了WebMvcConfigurationSupport，则在yml中配置的相关内容会失效。 需要重新指定静态资源映射
	 */
	@Override
	protected void addResourceHandlers(ResourceHandlerRegistry registry) {
		//资源映射
		registry.addResourceHandler("/**")
			.addResourceLocations("classpath:/static/")
			.addResourceLocations("classpath:/public/")
			.addResourceLocations("classpath:/resources/")
			.addResourceLocations("classpath:/META-INF/resources/");
		super.addResourceHandlers(registry);
	}

	@Override
	protected void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(loginInterceptor).addPathPatterns("/**")//拦截所有请求
			.excludePathPatterns("/css/**","/images/**","/js/**","/login","/checklogin","/login1");//例外
		//目前好像正常，如果发现druid和Swagger不能使用，例外中请添加"/swagger-ui.html/**","/v2/**","/swagger-resources/**","/druid/**"
		super.addInterceptors(registry);
	}
	

}