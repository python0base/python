package com.neuedu.office03.dao;

import com.neuedu.office03.model.Department;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.jdbc.SQL;

/**
 * SQL语句：比较复杂的SQL语句，可以将SQL语句集中化管理
 *
 */
public class DepartmentSqlProvider {

    public String insertSelective(Department record) {
        SQL sql = new SQL();
        sql.INSERT_INTO("department");
        
        if (record.getId() != null) {
            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
        }
        
        if (record.getName() != null) {
            sql.VALUES("name", "#{name,jdbcType=VARCHAR}");
        }
        
        if (record.getType() != null) {
            sql.VALUES("type", "#{type,jdbcType=VARCHAR}");
        }
        
        if (record.getTelephone() != null) {
            sql.VALUES("telephone", "#{telephone,jdbcType=VARCHAR}");
        }
        
        if (record.getFax() != null) {
            sql.VALUES("fax", "#{fax,jdbcType=VARCHAR}");
        }
        
        if (record.getDescription() != null) {
            sql.VALUES("description", "#{description,jdbcType=VARCHAR}");
        }
        
        if (record.getPredepartment() != null) {
            sql.VALUES("predepartment", "#{predepartment,jdbcType=VARCHAR}");
        }
        
        if (record.getDate() != null) {
            sql.VALUES("date", "#{date,jdbcType=DATE}");
        }
        
        return sql.toString();
    }

    public String updateByPrimaryKeySelective(Department record) {
        SQL sql = new SQL();
        sql.UPDATE("department");
        
        if (record.getName() != null) {
            sql.SET("name = #{name,jdbcType=VARCHAR}");
        }
        
        if (record.getType() != null) {
            sql.SET("type = #{type,jdbcType=VARCHAR}");
        }
        
        if (record.getTelephone() != null) {
            sql.SET("telephone = #{telephone,jdbcType=VARCHAR}");
        }
        
        if (record.getFax() != null) {
            sql.SET("fax = #{fax,jdbcType=VARCHAR}");
        }
        
        if (record.getDescription() != null) {
            sql.SET("description = #{description,jdbcType=VARCHAR}");
        }
        
        if (record.getPredepartment() != null) {
            sql.SET("predepartment = #{predepartment,jdbcType=VARCHAR}");
        }
        
        if (record.getDate() != null) {
            sql.SET("date = #{date,jdbcType=DATE}");
        }
        
        sql.WHERE("id = #{id,jdbcType=INTEGER}");
        
        return sql.toString();
    }
    public String selectByLike(Integer id, String name,String type) {
		SQL sql = new SQL();
		sql.SELECT("id, name, type, telephone, fax, description, predepartment, date");
		sql.FROM("department");
		sql.WHERE("1=1");
		if (null != id) {
			sql.WHERE("id  like  concat('%', #{id} , '%')");
		}
		if (null != name  && name.trim().length()>0) {
			sql.WHERE("name  like  concat('%', #{name} , '%')");
		}
		if (null != type  && type.trim().length()>0) {
			sql.WHERE("type  like  concat('%', #{type} , '%')");
		}
		return sql.toString();
	}
    
   
	 
	
		
	

    
	public String batchDelete(Map map) {
		Integer[] ids = (Integer[]) map.get("array");//数组是array，集合list是list
		StringBuffer sql = new StringBuffer("delete from department   where  id in (");
		for (int i = 0; i < ids.length; i++) {
			if (i == ids.length-1) {
				//最后个数组值
				sql.append(ids[i] + ")");
			}else {
				sql.append(ids[i] + ",");
			}
		}
		return sql.toString();
	}
}