package com.neuedu.office03.dao;

import java.util.Map;

import org.apache.ibatis.jdbc.SQL;


import com.neuedu.office03.model.Post;
import com.neuedu.office03.model.Try;

public class TrySqlProvider {

	 public String insertSelective(Try record) {
	        SQL sql = new SQL();
	        sql.INSERT_INTO("try");
	        
	        if (record.getId() != null) {
	            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
	        }
	        
	        if (record.getStartTime() != null) {
	            sql.VALUES("startTime", "#{startTime,jdbcType=DATE}");
	        }
	        
	        if (record.getEndTime() != null) {
	            sql.VALUES("endTime", "#{endTime,jdbcType=DATE}");
	        }
	        
	        if (record.getComment() != null) {
	            sql.VALUES("comment", "#{comment,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getResult() != null) {
	            sql.VALUES("result", "#{result,jdbcType=INTEGER}");
	        }
	        
	        if (record.getDealDate() != null) {
	            sql.VALUES("dealDate", "#{dealDate,jdbcType=DATE}");
	        }
	        
	        if (record.getRemark() != null) {
	            sql.VALUES("remark", "#{remark,jdbcType=VARCHAR}");
	        }
	        
            return sql.toString();
	    }

	    public String updateByPrimaryKeySelective(Try record) {
	        SQL sql = new SQL();
	        sql.UPDATE("try");
	        
	        if (record.getStartTime() != null) {
	            sql.SET("startTime = #{startTime,jdbcType=DATE}");
	        }
	        
	        if (record.getEndTime() != null) {
	            sql.SET("endTime = #{endTime,jdbcType=DATE}");
	        }
	        
	        if (record.getComment() != null) {
	            sql.SET("comment = #{comment,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getResult() != null) {
	            sql.SET("result = #{result,jdbcType=INTEGER}");
	        }
	        
	        if (record.getDealDate() != null) {
	            sql.SET("dealDate = #{dealDate,jdbcType=DATE}");
	        }
	        
	        if (record.getRemark() != null) {
	            sql.SET("remark = #{remark,jdbcType=VARCHAR}");
	        }
	        
	     
	        sql.WHERE("id = #{id,jdbcType=INTEGER}");
	        
	        return sql.toString();
	    }
	    public String selectByLike(Integer id, String startTime,String endTime) {
			SQL sql = new SQL(); SQL sql1 = new SQL();
			sql.SELECT("id, startTime, endTime, comment, result, dealDate, remark");
			sql.FROM("try");
			sql.WHERE("1=1");
			if (null != id) {
				sql.WHERE("id  like  concat('%', #{id} , '%')");
			}
			if (null != startTime  && startTime.trim().length()>0) {
				sql.WHERE("startTime  like  concat('%', #{startTime} , '%')");
			}
			if (null != endTime  && endTime.trim().length()>0) {
				sql.WHERE("endTime  like  concat('%', #{endTime} , '%')");
			}
			return sql.toString();
		}
	    
	    public String status(String status) {
			SQL sql = new SQL(); 
			sql.SELECT("id, name, sex, birth, nation, phone, status, graSchool, homeplace");
			sql.FROM("employee");
			
				sql.WHERE("status = #{status,jdbcType=VARCHAR}");
		
			return sql.toString();
		}
	    
	    
	    
		public String batchDelete(Map map) {
			Integer[] ids = (Integer[]) map.get("array");//数组是array，集合list是list
			StringBuffer sql = new StringBuffer("delete from try   where  id in (");
			for (int i = 0; i < ids.length; i++) {
				if (i == ids.length-1) {
					//最后个数组值
					sql.append(ids[i] + ")");
				}else {
					sql.append(ids[i] + ",");
				}
			}
			return sql.toString();
		}
}
