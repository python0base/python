package com.neuedu.office03.bll.impl;

import java.util.Date;
import java.util.List;


import com.neuedu.office03.model.Dimission;


public interface DimissionBLL {

	List<Dimission> selectAll();
	List<Dimission> selectByLike(Integer id,String name,Integer type);
	boolean insert(Dimission dimission);
	boolean update(Dimission dimission);
	Dimission selectById(Integer id);

	boolean batchDelete(Integer[] ids);
}
