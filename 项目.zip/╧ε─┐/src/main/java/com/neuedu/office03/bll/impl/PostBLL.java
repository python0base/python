package com.neuedu.office03.bll.impl;

import java.util.List;


import com.neuedu.office03.model.Post;

public interface PostBLL {
	List<Post> selectAll();
	
	  List<Post> selectByLike(Integer id,String name,String type); 
	  boolean insert(Post post); 
	  boolean update(Post post); 
	  Post selectById(Integer id);
	  
	  boolean batchDelete(Integer[] ids);
	 

}
