package com.neuedu.office03.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;


import com.neuedu.office03.model.Post;
@Mapper
public interface PostMapper {
	//
	
	  @Delete({ "delete from station", "where id = #{id,jdbcType=INTEGER}" }) int
	  deleteByPrimaryKey(Integer id);
	  
	  @Insert({ "insert into station (id, name, ", "type,number)",
	  "values (#{id,jdbcType=INTEGER}, #{name,jdbcType=VARCHAR}, ",
	  "#{type,jdbcType=VARCHAR},  #{number,jdbcType=INTEGER})" }) int insert(Post
	  record);
	 

  //  @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
 //   int insertSelective(Department record);

    @Select({
        "select",
        "id, name, type,number",
        "from station",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="type", property="type", jdbcType=JdbcType.VARCHAR),
        @Result(column="number", property="number", jdbcType=JdbcType.INTEGER)
    })
    Post selectByPrimaryKey(Integer id);

	
	
	  @UpdateProvider(type=PostSqlProvider.class,
	  method="updateByPrimaryKeySelective") int updateByPrimaryKeySelective(Post
	  record);
	  
	  @Update({ "update station", "set name = #{name,jdbcType=VARCHAR},",
	  "type = #{type,jdbcType=VARCHAR},", "number = #{number,jdbcType=INTEGER}",
	  "where id = #{id,jdbcType=INTEGER}" })
	  
	  int updateByPrimaryKey(Post record);
	 
    //查询
    @Select("select id, name, type,number  from station")
    List<Post> selectAll();
    //模糊查询
    @SelectProvider(type =PostSqlProvider.class,method = "selectByLike")
    List<Post> selectByLike(@Param("id")Integer id, @Param("name")String name,@Param("type")String type);
    
    //配置自动增长列的值，返回给调用者对象record，因为是引用类型，指向同一个内存区域，所说此处修改时，实参也必须同时变化
	
	  @InsertProvider(type=PostSqlProvider.class, method="insertSelective")
	  
	  @Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id") int
	  insertSelective(Post record);
	  
	  @DeleteProvider(type = PostSqlProvider.class,method = "batchDelete") int
	  batchDelete(Integer[] ids);
	 
}
