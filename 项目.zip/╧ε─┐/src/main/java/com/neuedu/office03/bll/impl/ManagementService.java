package com.neuedu.office03.bll.impl;
public interface ManagementService {
	boolean login(String name,String password);
}