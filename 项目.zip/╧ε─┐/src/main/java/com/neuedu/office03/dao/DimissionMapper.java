package com.neuedu.office03.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;


import com.neuedu.office03.model.Dimission;


@Mapper
public interface DimissionMapper {

	@Delete({
        "delete from dimission",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into dimission (id, name, ",
        "InDate, type, ",
        "direction, toTalents, ",
        "remark, dimissionDepId, ",
        "dimissionStaId, goDate)",
        "values (#{id,jdbcType=INTEGER}, #{name,jdbcType=VARCHAR}, ",
        "#{InDate,jdbcType=DATE}, #{type,jdbcType=INTEGER}, ",
        "#{direction,jdbcType=VARCHAR}, #{toTalents,jdbcType=INTEGER}, ",
        "#{remark,jdbcType=VARCHAR}, #{dimissionDepId,jdbcType=INTEGER}, ",
        "#{dimissionStaId,jdbcType=INTEGER}, #{goDate,jdbcType=DATE})"
    })
    int insert(Dimission record);

  //  @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
 //   int insertSelective(Department record);

    @Select({
        "select",
        "id, name, InDate, type, direction, toTalents, remark, dimissionDepId, dimissionStaId, goDate",
        "from dimission",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="InDate", property="InDate", jdbcType=JdbcType.DATE),
        @Result(column="type", property="type", jdbcType=JdbcType.INTEGER),
        @Result(column="direction", property="direction", jdbcType=JdbcType.VARCHAR),
        @Result(column="toTalents", property="toTalents", jdbcType=JdbcType.INTEGER),
        @Result(column="remark", property="remark", jdbcType=JdbcType.VARCHAR),
        @Result(column="dimissionDepId", property="dimissionDepId", jdbcType=JdbcType.INTEGER),
        @Result(column="dimissionStaId", property="dimissionStaId", jdbcType=JdbcType.INTEGER),
        @Result(column="goDate", property="goDate", jdbcType=JdbcType.DATE)
    })
    Dimission selectByPrimaryKey(Integer id);

    @UpdateProvider(type=DimissionSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Dimission record);

    @Update({
        "update dimission",
        "set name = #{name,jdbcType=VARCHAR},",
          "InDate = #{InDate,jdbcType=DATE},",
          "type = #{type,jdbcType=INTEGER},",
          "direction = #{direction,jdbcType=VARCHAR},",
          "toTalents = #{toTalents,jdbcType=INTEGER},",
          "remark = #{remark,jdbcType=VARCHAR},",
          "dimissionDepId = #{dimissionDepId,jdbcType=INTEGER},",
          "dimissionStaId = #{dimissionStaId,jdbcType=INTEGER},",
          "goDate = #{goDate,jdbcType=DATE}",
          
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(Dimission record);
    //查询
    @Select("select id, name, InDate, type, direction, toTalents, remark, dimissionDepId, dimissionStaId, goDate  from dimission")
    List<Dimission> selectAll();
    
   
    //模糊查询
    //模糊查询
    @SelectProvider(type = DimissionSqlProvider.class,method = "selectByLike")
    List<Dimission> selectByLike(@Param("id")Integer id, @Param("name")String name,@Param("type")Integer type);
    

    
    //配置自动增长列的值，返回给调用者对象record，因为是引用类型，指向同一个内存区域，所说此处修改时，实参也必须同时变化
    @InsertProvider(type=DimissionSqlProvider.class, method="insertSelective")
    @Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
     int insertSelective(Dimission record);
    
    @DeleteProvider(type = DimissionSqlProvider.class,method = "batchDelete")
    int batchDelete(Integer[] ids);
}
