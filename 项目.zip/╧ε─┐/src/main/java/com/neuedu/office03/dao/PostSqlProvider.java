package com.neuedu.office03.dao;

import java.util.Map;

import org.apache.ibatis.jdbc.SQL;


import com.neuedu.office03.model.Post;

public class PostSqlProvider {

	 public String insertSelective(Post record) {
	        SQL sql = new SQL();
	        sql.INSERT_INTO("station");
	        
	        if (record.getId() != null) {
	            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
	        }
	        
	        if (record.getName() != null) {
	            sql.VALUES("name", "#{name,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getType() != null) {
	            sql.VALUES("type", "#{type,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getNumber() != null) {
	            sql.VALUES("number", "#{number,jdbcType=INTEGER}");
	        }
	        
	        return sql.toString();
	    }

	    public String updateByPrimaryKeySelective(Post record) {
	        SQL sql = new SQL();
	        sql.UPDATE("station");
	        
	        if (record.getName() != null) {
	            sql.SET("name = #{name,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getType() != null) {
	            sql.SET("type = #{type,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getNumber() != null) {
	            sql.SET("number = #{number,jdbcType=INTEGER}");
	        }
	        
	        sql.WHERE("id = #{id,jdbcType=INTEGER}");
	        
	        return sql.toString();
	    }
	    public String selectByLike(Integer id, String name,String type) {
			SQL sql = new SQL();
			sql.SELECT("id, name, type, number");
			sql.FROM("station");
			sql.WHERE("1=1");
			if (null != id) {
				sql.WHERE("id  like  concat('%', #{id} , '%')");
			}
			if (null != name  && name.trim().length()>0) {
				sql.WHERE("name  like  concat('%', #{name} , '%')");
			}
			if (null != type  && type.trim().length()>0) {
				sql.WHERE("type  like  concat('%', #{type} , '%')");
			}
			return sql.toString();
		}
	    
	    
		public String batchDelete(Map map) {
			Integer[] ids = (Integer[]) map.get("array");//数组是array，集合list是list
			StringBuffer sql = new StringBuffer("delete from station   where  id in (");
			for (int i = 0; i < ids.length; i++) {
				if (i == ids.length-1) {
					//最后个数组值
					sql.append(ids[i] + ")");
				}else {
					sql.append(ids[i] + ",");
				}
			}
			return sql.toString();
		}
}
