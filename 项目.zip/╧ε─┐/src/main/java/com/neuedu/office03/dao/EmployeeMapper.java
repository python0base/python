package com.neuedu.office03.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;


import com.neuedu.office03.model.Employee;

@Mapper
public interface EmployeeMapper {

	 @Delete({
	        "delete from employee1",
	        "where id = #{id,jdbcType=INTEGER}"
	    })
	    int deleteByPrimaryKey(Integer id);

	    @Insert({
	        "insert into employee (id, name, ",
	        "departmentId,  stationId, ",
	        "employDate,  form, source)",
	        "values (#{id,jdbcType=INTEGER}, #{name,jdbcType=VARCHAR}, ",
	        " #{departmentId,jdbcType=INTEGER}, ",
	        " #{stationId,jdbcType=INTEGER}, ",
	        " #{employDate,jdbcType=DATE}, ",
	        "#{form,jdbcType=INTEGER}, ",
	        "#{source,jdbcType=VARCHAR}) "   
	    })
	    int insert(Employee record);

	  //  @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
	 //   int insertSelective(Department record);

	    @Select({
	    	"select id, name, departmentId,  stationId, employDate,"
		    		+ "  form, source  from employee",
	        "where id = #{id,jdbcType=INTEGER}"
	    })
	    @Results({
	        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
	        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
	        @Result(column="departmentId", property="departmentId", jdbcType=JdbcType.INTEGER),
	        @Result(column="stationId", property="stationId", jdbcType=JdbcType.INTEGER),
	        @Result(column="employDate", property="employDate", jdbcType=JdbcType.DATE),
	        @Result(column="form", property="form", jdbcType=JdbcType.INTEGER),
	        @Result(column="source", property="source", jdbcType=JdbcType.VARCHAR)
	    })
	    Employee selectByPrimaryKey(Integer id);

	  @UpdateProvider(type=EmployeeSqlProvider.class, method="updateByPrimaryKeySelective")
	    int updateByPrimaryKeySelective(Employee record);

	   @Update({
	        "update employee",
	        "set name = #{name,jdbcType=VARCHAR},",
	          "departmentId = #{departmentId,jdbcType=INTEGER},",
	          "stationId = #{stationId,jdbcType=INTEGER},",
	          "employDate = #{employDate,jdbcType=DATE},",
	          "form = #{form,jdbcType=INTEGER},",
	          "source = #{source,jdbcType=VARCHAR},",
	         
	        "where id = #{id,jdbcType=INTEGER}"
	    })
	    int updateByPrimaryKey(Employee record);

	   
	    //查询
	    @Select("select id, name, departmentId,  stationId,  employDate,"
	    		+ " form, source   from employee")
	    		
	    List<Employee> selectAll();
	    
	   
	    //模糊查询
	    @SelectProvider(type = EmployeeSqlProvider.class,method = "selectByLike")
	    List<Employee> selectByLike(@Param("id")Integer id, @Param("name")String name,@Param("form")Integer form);
	    
	   
	    //配置自动增长列的值，返回给调用者对象record，因为是引用类型，指向同一个内存区域，所说此处修改时，实参也必须同时变化
	    @InsertProvider(type=EmployeeSqlProvider.class, method="insertSelective")
	    @Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
	     int insertSelective(Employee record);
	    
	    @DeleteProvider(type = EmployeeSqlProvider.class,method = "batchDelete")
	    int batchDelete(Integer[] ids);
}
