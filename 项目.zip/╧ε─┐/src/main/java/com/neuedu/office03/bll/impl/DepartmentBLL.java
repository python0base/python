package com.neuedu.office03.bll.impl;

import java.util.List;

import com.neuedu.office03.model.Department;

public interface DepartmentBLL {
	List<Department> selectAll();
	List<Department> selectByLike(Integer id,String name,String type);
	boolean insert(Department department);
	boolean update(Department department);
	Department selectById(Integer id);
	
	boolean batchDelete(Integer[] ids);
}
