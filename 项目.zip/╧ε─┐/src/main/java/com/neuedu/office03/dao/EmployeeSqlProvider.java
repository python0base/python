package com.neuedu.office03.dao;

import java.util.Map;

import org.apache.ibatis.jdbc.SQL;


import com.neuedu.office03.model.Employee;

public class EmployeeSqlProvider {

	 public String insertSelective(Employee record) {
	        SQL sql = new SQL();
	        sql.INSERT_INTO("employee");
	        
	        if (record.getId() != null) {
	            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
	        }
	        if (record.getName() != null) {
	            sql.VALUES("name", "#{name,jdbcType=VARCHAR}");
	        }
	       
	    	 if (record.getDepartmentId() != null) {
	            sql.VALUES("departmentId", "#{departmentId,jdbcType=INTEGER}");
	        }
	       
	        if (record.getStationId() != null) {
	            sql.VALUES("stationId", "#{stationId,jdbcType=INTEGER}");
	        }
	     
	        if (record.getEmployDate() != null) {//10
	            sql.VALUES("employDate", "#{employDate,jdbcType=DATE}");
	        }
	       
	        if (record.getForm() != null) {
	            sql.VALUES("form", "#{form,jdbcType=INTEGER}");
	        }
	        if (record.getSource() != null) {
	            sql.VALUES("source", "#{source,jdbcType=VARCHAR}");
	        }
	       
	        return sql.toString();
	    }

	
	   
	   public String updateByPrimaryKeySelective(Employee record) {
	        SQL sql = new SQL();
	        sql.UPDATE("employee");
	        
	        if (record.getName() != null) {
	            sql.SET("name = #{name,jdbcType=VARCHAR}");
	        }
	        if (record.getDepartmentId() != null) {
	            sql.SET("departmentId = #{departmentId,jdbcType=INTEGER}");
	        }
	        if (record.getStationId() != null) {
	            sql.SET("stationId = #{stationId,jdbcType=INTEGER}");
	        }
	        if (record.getEmployDate() != null) {
	            sql.SET("employDate = #{employDate,jdbcType=DATE}");
	        } 
	        if (record.getForm() != null) {
	            sql.SET("form = #{form,jdbcType=INTEGER}");
	        }
	        if (record.getSource() != null) {
	            sql.SET("source = #{source,jdbcType=VARCHAR}");
	        }
	       
	        sql.WHERE("id = #{id,jdbcType=INTEGER}");
	        
	        return sql.toString();
	    }
	  
	 
	   
	    public String selectByLike(Integer id, String name,Integer form) {
			SQL sql = new SQL();
			sql.SELECT("id, name, sex, birth, idcard, departmentId, departmentName, stationId, stationName, employDate,"
		    		+ " workDate, form, source, politics, folk, nation,phone, email, height, blood,"
		    		+ "status, homeplace,seat,eduBack, eduDegree, graSchool, speciality, graDate, tag");
			sql.FROM("employee");
			sql.WHERE("1=1");
			if (null != id) {
				sql.WHERE("id  like  concat('%', #{id} , '%')");
			}
			if (null != name  && name.trim().length()>0) {
				sql.WHERE("name  like  concat('%', #{name} , '%')");
			}
			if (null != form  ) {
				sql.WHERE("form  like  concat('%', #{form} , '%')");
			}
			return sql.toString();
		}
	    
	    
		public String batchDelete(Map map) {
			Integer[] ids = (Integer[]) map.get("array");//数组是array，集合list是list
			StringBuffer sql = new StringBuffer("delete from employee   where  id in (");
			for (int i = 0; i < ids.length; i++) {
				if (i == ids.length-1) {
					//最后个数组值
					sql.append(ids[i] + ")");
				}else {
					sql.append(ids[i] + ",");
				}
			}
			return sql.toString();
		}
}
