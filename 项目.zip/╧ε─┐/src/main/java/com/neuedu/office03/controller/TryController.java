package com.neuedu.office03.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;
import com.neuedu.office03.bll.impl.DepartmentBLL;
import com.neuedu.office03.bll.impl.TryBLL;
import com.neuedu.office03.model.Department;

import com.neuedu.office03.model.Try;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(tags = "试用期信息控制器")
@Controller
public class TryController {

	@Autowired
	private TryBLL tryBLL;

	@GetMapping(value = { "/try/managerTry" })
	public String managerDepartments(Model model) {
		// 查询所有部门信息
		List<Try> try1 = tryBLL.selectAll();
		// 准备统一返回数据类型的对象
		ResultBean<List<Try>> resultBean = new ResultBean<List<Try>>(200, true, "查询所有试用期信息成功", try1);
		// 通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/try/managerTry";
	}

	@ApiOperation(value = "根据试用期编号、试用期名称、试用期类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query", name = "id", value = "试用期编号", required = false, dataType = "Integer", defaultValue = ""),
			@ApiImplicitParam(paramType = "query", name = "startTime", value = "试用期开始日期", required = false, dataType = "String", defaultValue = ""),
			@ApiImplicitParam(paramType = "query", name = "endTime", value = "试用期截止日期", required = false, dataType = "String", defaultValue = "") })
	@GetMapping(value = { "/try/selectbylike" })
	public String selectbylike(Integer id, String startTime, String endTime, Model model) {
		// 多条件组合模糊查询
		List<Try> try1 = tryBLL.selectByLike(id, startTime, endTime);
		// 准备统一返回数据类型的对象
		ResultBean<List<Try>> resultBean = new ResultBean<List<Try>>(200, true, "查询所有试用期信息成功", try1);
		// 通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/try/managerTry";
	}

	@ApiOperation(value = "根据试用期编号、试用期名称、试用期类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query", name = "status", value = "试用期编号", required = false, dataType = "String", defaultValue = "")

	})

	/**
	 * 返回增加部门信息的页面
	 * 
	 * @return
	 */
	@GetMapping(value = { "try/createTry" })
	public String createTry() {
		return "/try/createTry";
	}

	/**
	 * 返回修改部门信息的页面
	 * 
	 * @return
	 */
	@GetMapping(value = { "try/updataTry" })
	public String updataTry(Integer id, Model model) {
		Try try1 = tryBLL.selectById(id);
		ResultBean<Try> resultBean = new ResultBean<Try>(200, true, "查询试用期信息成功", try1);
		// 传递部门实体信息数据
		model.addAttribute("rdata", resultBean);
		return "/try/updataTry";
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	/**
	 * 返回增加/修改的结果JSON
	 * 
	 * @param id
	 * @param name
	 * @param type
	 * @param telephone
	 * @param fax
	 * @param description
	 * @param predepartment
	 * @param date
	 * @return
	 * @throws ParseException
	 */

	@ApiOperation(value = "试用期信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query", name = "try1", value = "部门信息实体对象", required = true) })

	@PostMapping(value = { "/try/save" })
	@ResponseBody
	public ResultBean<String> save(Try try1) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// department是实参
		// Department department = new Department(id, name, type, telephone, fax,
		// description, predepartment, sdf.parse(date));
		// Department department = new Department(id, name, type, telephone, fax,
		// description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (null == try1.getId()) {
			// 增加部门
			if (tryBLL.insert(try1)) {
				resultBean.setCode(200);
				resultBean.setMessage("增加员工试用期信息成功！新增的试用期员工编号是" + try1.getId());// 获取自动增长列的值
			} else {
				resultBean.setCode(500);
				resultBean.setMessage("增加员工试用期信息失败！");
			}
		} else {
			// 修改部门
			if (tryBLL.update(try1)) {
				resultBean.setCode(200);
				resultBean.setMessage("修改试用期员工信息成功！");
			} else {
				resultBean.setCode(500);
				resultBean.setMessage("修改试用期员工信息失败！");
			}
		}
		return resultBean;
	}

	@ApiOperation(value = "试用期员工信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query", name = "try1", value = "试用期员工信息实体对象", required = true) })

	@PostMapping(value = { "/try/save1" })
	@ResponseBody
	public ResultBean<String> save1(Try try1) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		// department是实参
		// Department department = new Department(id, name, type, telephone, fax,
		// description, predepartment, sdf.parse(date));
		// Department department = new Department(id, name, type, telephone, fax,
		// description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();

		// 增加部门
		if (tryBLL.insert(try1)) {
			resultBean.setCode(200);
			resultBean.setMessage("增加试用期员工信息成功！新增的试用期员工编号是" + try1.getId());// 获取自动增长列的值
		} else {
			resultBean.setCode(500);
			resultBean.setMessage("增加试用期员工信息失败！");
		}

		return resultBean;
	}

	@PostMapping(value = { "try/batchdelete" })
	@ResponseBody
	public ResultBean<String> batchdelete(@RequestParam("ids[]") Integer[] ids) {
		boolean flag = tryBLL.batchDelete(ids);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("试用期员工信息删除成功~~~");
		} else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("试用期员工信息删除失败~~~");
		}
		return resultBean;
	}
}
