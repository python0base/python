package com.neuedu.office03.model;

import java.io.Serializable;
import java.util.Date;

public class Dimission  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3345301045174578464L;

	private Integer id;

    private String name;

    private Date InDate;

    private Integer type;

    private String direction;

    private Integer toTalents;

    private String remark;

    private Integer dimissionDepId;
    
    private Integer dimissionStaId;

    private Date goDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getInDate() {
		return InDate;
	}

	public void setInDate(Date inDate) {
		InDate = inDate;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public Integer getToTalents() {
		return toTalents;
	}

	public void setToTalents(Integer toTalents) {
		this.toTalents = toTalents;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getDimissionDepId() {
		return dimissionDepId;
	}

	public void setDimissionDepId(Integer dimissionDepId) {
		this.dimissionDepId = dimissionDepId;
	}

	public Integer getDimissionStaId() {
		return dimissionStaId;
	}

	public void setDimissionStaId(Integer dimissionStaId) {
		this.dimissionStaId = dimissionStaId;
	}

	public Date getGoDate() {
		return goDate;
	}

	public void setGoDate(Date goDate) {
		this.goDate = goDate;
	}

	public Dimission(Integer id, String name, Date inDate, Integer type, String direction, Integer toTalents,
			String remark, Integer dimissionDepId, Integer dimissionStaId, Date goDate) {
		super();
		this.id = id;
		this.name = name;
		InDate = inDate;
		this.type = type;
		this.direction = direction;
		this.toTalents = toTalents;
		this.remark = remark;
		this.dimissionDepId = dimissionDepId;
		this.dimissionStaId = dimissionStaId;
		this.goDate = goDate;
	}

	public Dimission() {
		super();
	}

	public Dimission(String name, Date inDate, Integer type, String direction, Integer toTalents, String remark,
			Integer dimissionDepId, Integer dimissionStaId, Date goDate) {
		super();
		this.name = name;
		InDate = inDate;
		this.type = type;
		this.direction = direction;
		this.toTalents = toTalents;
		this.remark = remark;
		this.dimissionDepId = dimissionDepId;
		this.dimissionStaId = dimissionStaId;
		this.goDate = goDate;
	}

	@Override
	public String toString() {
		 StringBuilder sb = new StringBuilder();
	        sb.append(getClass().getSimpleName());
	        sb.append(" [");
	        sb.append("Hash = ").append(hashCode());
	        sb.append(", id=").append(id);
	        sb.append(", name=").append(name);
	        sb.append(", inDate=").append(InDate);
	        sb.append(", type=").append(type);
	        sb.append(", direction=").append(direction);
	        sb.append(", toTalents=").append(toTalents);
	        sb.append(", remark=").append(remark);
	        sb.append(", dimissionDepId=").append(dimissionDepId);
	        sb.append(", dimissionStaId=").append(dimissionStaId);
	        sb.append(", goDate=").append(goDate);
	        sb.append(", serialVersionUID=").append(serialVersionUID);
	        sb.append("]");
	        return sb.toString();
	}

   
    
    
    
    
}
