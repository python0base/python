package com.neuedu.office03.component;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;


@Component
public class DateConverter implements Converter<String, Date> {

	@Override
	public Date convert(String value) {
		// TODO Auto-generated method stub
		SimpleDateFormat  dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
		Date date = null;
		try {
			date = dateFormat.parse(value);
			
		}catch(ParseException e){
			e.printStackTrace();
		}
		return date;
	}


}
