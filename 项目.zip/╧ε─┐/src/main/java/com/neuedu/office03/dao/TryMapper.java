package com.neuedu.office03.dao;


import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

import com.neuedu.office03.model.Department;

import com.neuedu.office03.model.Post;
import com.neuedu.office03.model.Try;
@Mapper

public interface TryMapper  {

	 @Delete({ "delete from try", "where id = #{id,jdbcType=INTEGER}" }) 
	 int deleteByPrimaryKey(Integer id);
	  
	 @Insert({
	        "insert into try (id, startTime, ",
	        "endTime, comment, ",
	        "result, dealDate, ",
	        "remark)",
	        "values (#{id,jdbcType=INTEGER}, #{startTime,jdbcType=DATE}, ",
	        "#{endTime,jdbcType=DATE}, #{comment,jdbcType=VARCHAR}, ",
	        "#{result,jdbcType=INTEGER}, #{dealDate,jdbcType=DATE}, ",
	        "#{remark,jdbcType=VARCHAR})"
	    })
	  int insert(Try record);
	 

 //  @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
//   int insertSelective(Department record);

	 @Select({
	        "select",
	        "id, startTime, endTime, comment, result, dealDate, remark",
	        "from try",
	        "where id = #{id,jdbcType=INTEGER}"
	    })
	    @Results({
	        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
	        @Result(column="startTime", property="startTime", jdbcType=JdbcType.DATE),
	        @Result(column="endTime", property="endTime", jdbcType=JdbcType.DATE),
	        @Result(column="comment", property="comment", jdbcType=JdbcType.VARCHAR),
	        @Result(column="result", property="result", jdbcType=JdbcType.INTEGER),
	        @Result(column="dealDate", property="dealDate", jdbcType=JdbcType.DATE),
	        @Result(column="remark", property="remark", jdbcType=JdbcType.VARCHAR),
	        
	    })
	 Try selectByPrimaryKey(Integer id);
	 @Select({
	        "select",
	        "id, startTime, endTime, comment, result, dealDate, remark",
	        "from try",
	        "where result ='1'"
	    })
	   
	 Try selectByPrimaryKey1(Integer id);
	 
	

	    @UpdateProvider(type=TrySqlProvider.class, method="updateByPrimaryKeySelective")
	    int updateByPrimaryKeySelective(Try record);

	    @Update({
	        "update try",
	        "set startTime = #{startTime,jdbcType=DATE},",
	          "endTime = #{endTime,jdbcType=DATE},",
	          "comment = #{comment,jdbcType=VARCHAR},",
	          "result = #{result,jdbcType=INTEGER},",
	          "dealDate = #{dealDate,jdbcType=DATE},",
	          "remark = #{remark,jdbcType=VARCHAR}",
	       
	        "where id = #{id,jdbcType=INTEGER}"
	    })
	    int updateByPrimaryKey(Try record);
	    //查询
	    @Select("select id, startTime, endTime, comment, result, dealDate, remark  from try")
	    List<Try> selectAll();
	    

	    //模糊查询
	    @SelectProvider(type = TrySqlProvider.class,method = "selectByLike")
	    List<Try> selectByLike(@Param("id")Integer id, @Param("startTime")String startTime,@Param("endTime")String endTime);
	    
	
	    //配置自动增长列的值，返回给调用者对象record，因为是引用类型，指向同一个内存区域，所说此处修改时，实参也必须同时变化
	    @InsertProvider(type=TrySqlProvider.class, method="insertSelective")
	    @Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
	     int insertSelective(Try record);
	    
	    @DeleteProvider(type = TrySqlProvider.class,method = "batchDelete")
	    int batchDelete(Integer[] ids);
	    
}
