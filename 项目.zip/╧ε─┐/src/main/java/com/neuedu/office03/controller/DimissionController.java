package com.neuedu.office03.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;

import com.neuedu.office03.bll.impl.DimissionBLL;

import com.neuedu.office03.model.Dimission;


import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(tags = "离职信息控制器")
@Controller
public class DimissionController {
	@Autowired
	private DimissionBLL dimissionBLL;
	
	@GetMapping(value = {"/dimission/managerDimission"})
	public String managerDepartments(Model model) {
		//查询所有部门信息
		List<Dimission> dimission = dimissionBLL.selectAll();
		//准备统一返回数据类型的对象
		ResultBean<List<Dimission>> resultBean = new ResultBean<List<Dimission>>(200, true, "查询所有离职员工信息成功", dimission);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/dimission/managerDimission";
	}
	
	
	
	@ApiOperation(value = "根据离职员工编号、离职员工名称、离职员工类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "id",value = "离职编号",required = false,dataType = "Integer",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "name",value = "离职名称",required = false,dataType = "String",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "type",value = "离职类型",required = false,dataType = "Integer",defaultValue = "")
	})
	@GetMapping(value = {"/dimission/selectbylike"})
	public String selectbylike(Integer id,String name,Integer type,Model model) {
		//多条件组合模糊查询
		List<Dimission> dimission = dimissionBLL.selectByLike(id, name, type);
		//准备统一返回数据类型的对象
		ResultBean<List<Dimission>> resultBean = new ResultBean<List<Dimission>>(200, true, "查询所有离职员工信息成功", dimission);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/dimission/managerDimission";
	}
	
	
	@ApiOperation(value = "根据试用期编号、试用期名称、试用期类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "status",value = "试用期编号",required = false,dataType = "String",defaultValue = "")
			
	})

	/**
	 * 返回增加部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"dimission/createDimission"})
	public String createDimission() {
		return "/dimission/createDimission";
	}
	
	/**
	 * 返回修改部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"dimission/updataDimission"})
	public String updataDepartment(Integer id, Model model) {
		Dimission dimission = dimissionBLL.selectById(id);
		ResultBean<Dimission> resultBean = new ResultBean<Dimission>(200, true, "查询离职员工信息成功",dimission);
		//传递部门实体信息数据
		model.addAttribute("rdata", resultBean);
		return "/dimission/updataDimission";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat  dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
	
		dateFormat.setLenient(false);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat,true));
	}
	/**
	 * 返回增加/修改的结果JSON
	 * @param id
	 * @param name
	 * @param type
	 * @param telephone
	 * @param fax
	 * @param description
	 * @param predepartment
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	
	
	@ApiOperation(value = "离职员工信息的新增操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "dimission",value = "离职员工信息实体对象",required = true)
	})

	@PostMapping(value = {"dimission/save"})
	@ResponseBody
	public ResultBean<String> save(Dimission dimission) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		
			//修改部门
			if (dimissionBLL.update(dimission)) {
				resultBean.setCode(200);
				resultBean.setMessage("修改离职员工信息成功！");
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("修改离职员工信息失败！");
			}
	
		return resultBean;
	}
	
	@ApiOperation(value = "离职员工信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "dimission",value = "离职员工信息实体对象",required = true)
	})

	@PostMapping(value = {"dimission/save2"})
	@ResponseBody
	public ResultBean<String> save2(Dimission dimission) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		
			//增加部门
			if (dimissionBLL.insert(dimission)) {
				resultBean.setCode(200);
				resultBean.setMessage("增加离职员工信息成功！新增的离职员工编号是" + dimission.getId());//获取自动增长列的值
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("增加离职员工信息失败！");
			}
		
		return resultBean;
	}
	
	
	@PostMapping(value = {"dimission/batchdelete"})
	@ResponseBody
	public ResultBean<String> batchdelete(@RequestParam("ids[]")Integer[] ids) {
		boolean flag = dimissionBLL.batchDelete(ids);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("离职员工信息删除成功~~~");
		}else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("离职员工信息删除失败~~~");
		}
		return resultBean;
	}
}