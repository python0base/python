package com.neuedu.office03.bll.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.neuedu.office03.dao.TryMapper;

import com.neuedu.office03.model.Try;
@Service
public class TryBLLImpl implements TryBLL {
	@Autowired
	private TryMapper tryMapper;

	@Override
	public List<Try> selectAll() {
		// TODO Auto-generated method stub
		return tryMapper.selectAll();
	}

	@Override
	public List<Try> selectByLike(Integer id, String startTime, String endTime) {
		// TODO Auto-generated method stub
		return tryMapper.selectByLike(id, startTime, endTime);
	}

	@Override
	public boolean insert(Try try1) {
		// TODO Auto-generated method stub
		int line = tryMapper.insertSelective(try1);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}

	@Transactional(rollbackFor=Exception.class)
	@Override
	public boolean update(Try try1) {
		// TODO Auto-generated method stub
		// 此处忽略业务逻辑处理过程：参见SSM框架的描述
				// ……
				// 调用DAO的方法完成修改部门的数据库操作，返回受影响的行数
				int line = tryMapper.updateByPrimaryKeySelective(try1);
				// 返回操作是否成功
				return line == 1 ? true : false;
	}

	@Override
	public Try selectById(Integer id) {
		// TODO Auto-generated method stub
		return tryMapper.selectByPrimaryKey(id);
	}

	@Transactional(isolation = Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	@Override
	public boolean batchDelete(Integer[] ids) {
		// TODO Auto-generated method stub
		int line = tryMapper.batchDelete(ids);
		return line>0?true:false;
	}





	@Override
	public List<Try> selectByLike1(Integer result) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Try> selectByLike2(Integer result) {
		// TODO Auto-generated method stub
		return null;
	}


}
