package com.neuedu.office03.bll.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.neuedu.office03.dao.DepartmentMapper;
import com.neuedu.office03.model.Department;
@Service
public class DepartmentBLLImpl implements DepartmentBLL {
	@Autowired
	private DepartmentMapper departmentMapper;

	@Override
	public List<Department> selectAll() {
		// TODO Auto-generated method stub
		return departmentMapper.selectAll();
	}

	@Override
	public List<Department> selectByLike(Integer id, String name, String type) {
		// TODO Auto-generated method stub
		return departmentMapper.selectByLike(id, name, type);
	}

	@Override
	public boolean insert(Department department) {
		// TODO Auto-generated method stub
		int line = departmentMapper.insertSelective(department);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}

	@Transactional(rollbackFor=Exception.class)
	@Override
	public boolean update(Department department) {
		// TODO Auto-generated method stub
		// 此处忽略业务逻辑处理过程：参见SSM框架的描述
				// ……
				// 调用DAO的方法完成修改部门的数据库操作，返回受影响的行数
				int line = departmentMapper.updateByPrimaryKeySelective(department);
				// 返回操作是否成功
				return line == 1 ? true : false;
	}

	@Override
	public Department selectById(Integer id) {
		// TODO Auto-generated method stub
		return departmentMapper.selectByPrimaryKey(id);
	}

	@Transactional(isolation = Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	@Override
	public boolean batchDelete(Integer[] ids) {
		// TODO Auto-generated method stub
		int line = departmentMapper.batchDelete(ids);
		return line>0?true:false;
	}
}
