package com.neuedu.office03.bll.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.neuedu.office03.dao.EmployeeMapper;
import com.neuedu.office03.model.Employee;
@Service
public class EmployeeBLLImpl implements EmployeeBLL {
	@Autowired
	private EmployeeMapper  employeeMapper;

	@Override
	public List<Employee> selectAll() {
		// TODO Auto-generated method stub
		return employeeMapper.selectAll();
	}

	@Override
	public List<Employee> selectByLike(Integer id, String name, Integer form) {
		// TODO Auto-generated method stub
		return employeeMapper.selectByLike(id, name, form);
	}

	@Override
	public boolean insert(Employee employee) {
		// TODO Auto-generated method stub
		int line = employeeMapper.insertSelective(employee);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}
	@Transactional(rollbackFor=Exception.class)
	@Override
	public Employee selectById(Integer id) {
	
		// TODO Auto-generated method stub
		return employeeMapper.selectByPrimaryKey(id);
	}
	@Transactional(isolation = Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	@Override
	public boolean batchDelete(Integer[] ids) {
		// TODO Auto-generated method stub
		int line = employeeMapper.batchDelete(ids);
		return line>0?true:false;
	}

	@Override
	public boolean update(Employee employee) {
		// TODO Auto-generated method stub
		int line = employeeMapper.updateByPrimaryKeySelective(employee);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}

	/*
	 * @Override public boolean update(Employee employee) { // TODO Auto-generated
	 * method stub return false; }
	 */

}
