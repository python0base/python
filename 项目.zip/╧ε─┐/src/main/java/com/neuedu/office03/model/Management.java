package com.neuedu.office03.model;

import java.io.Serializable;

public class Management implements Serializable {
	
	private static final long serialVersionUID = 8576913686152549334L;

	private Integer id;

    private String password;

    private String name;

    public Management() {
	}

    public Management(String password, String name) {
		super();
		this.password = password;
		this.name = name;
	}

	public Management(Integer id, String password, String name) {
		super();
		this.id = id;
		this.password = password;
		this.name = name;
	}

	public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", password=").append(password);
        sb.append(", name=").append(name);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}