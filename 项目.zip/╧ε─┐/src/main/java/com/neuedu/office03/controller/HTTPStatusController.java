package com.neuedu.office03.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.GetMapping;

public class HTTPStatusController implements ErrorController {
	private static final String ERROR_PATH="/error";

	@Override
	public String getErrorPath() {
		// TODO Auto-generated method stub
		return ERROR_PATH;
	}
	@GetMapping(value= ERROR_PATH)
	public String handle(HttpServletResponse response) {
		int code = response.getStatus();
		
		return ERROR_PATH+"/"+code;
	}

}
