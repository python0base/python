package com.neuedu.office03.model;

import java.io.Serializable;
import java.util.Date;

public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6215985880909473636L;

	private Integer id;

    private String name;

    private Integer departmentId;

    

    private Integer stationId;//8
    
   

    private Date employDate;

   

    private Integer form;

    private String source;

    
	

	public Employee(Integer id, String name, Integer departmentId, Integer stationId, Date employDate, Integer form,
			String source) {
		super();
		this.id = id;
		this.name = name;
		this.departmentId = departmentId;
		this.stationId = stationId;
		this.employDate = employDate;
		this.form = form;
		this.source = source;
	}




	public Employee(String name, Integer departmentId, Integer stationId, Date employDate, Integer form,
			String source) {
		super();
		this.name = name;
		this.departmentId = departmentId;
		this.stationId = stationId;
		this.employDate = employDate;
		this.form = form;
		this.source = source;
	}




	public Employee() {
		super();
	}




	public Integer getId() {
		return id;
	}




	public void setId(Integer id) {
		this.id = id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public Integer getDepartmentId() {
		return departmentId;
	}




	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}




	public Integer getStationId() {
		return stationId;
	}




	public void setStationId(Integer stationId) {
		this.stationId = stationId;
	}




	public Date getEmployDate() {
		return employDate;
	}




	public void setEmployDate(Date employDate) {
		this.employDate = employDate;
	}




	public Integer getForm() {
		return form;
	}




	public void setForm(Integer form) {
		this.form = form;
	}




	public String getSource() {
		return source;
	}




	public void setSource(String source) {
		this.source = source;
	}




	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", id=").append(id);
        sb.append(", name=").append(name);
        sb.append(", departmentId=").append(departmentId);
        sb.append(", stationId=").append(stationId);//8
        sb.append(", employDate=").append(employDate);
        sb.append(", form=").append(form);
        sb.append(", source=").append(source);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
	}
  
    
    
    
}
