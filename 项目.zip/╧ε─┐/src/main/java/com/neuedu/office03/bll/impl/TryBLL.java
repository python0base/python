package com.neuedu.office03.bll.impl;

import java.util.List;


import com.neuedu.office03.model.Try;

public interface TryBLL {

	List<Try> selectAll();
	
	  List<Try> selectByLike(Integer id,String startTime,String endTime); 
	  List<Try> selectByLike1(Integer result); 
	
	  List<Try> selectByLike2(Integer result); 
	  boolean insert(Try try1); 
	  boolean update(Try try1); 
	 Try selectById(Integer id);

	  boolean batchDelete(Integer[] ids);
}
