package com.neuedu.office03.model;

import java.io.Serializable;
import java.util.Date;

public class Try implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6408373529135086240L;
	
	private Integer id;

    private Date startTime;

    private Date endTime;

    private String comment;

    private Integer result;

    private Date dealDate;

    private String remark;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public Integer getResult() {
		return result;
	}

	public void setResult(Integer result) {
		this.result = result;
	}

	public Date getDealDate() {
		return dealDate;
	}

	public void setDealDate(Date dealDate) {
		this.dealDate = dealDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Try(Integer id, Date startTime, Date endTime, String comment, Integer result, Date dealDate, String remark) {
		super();
		this.id = id;
		this.startTime = startTime;
		this.endTime = endTime;
		this.comment = comment;
		this.result = result;
		this.dealDate = dealDate;
		this.remark = remark;
	}

	public Try() {
		super();
	}

	public Try(Date startTime, Date endTime, String comment, Integer result, Date dealDate, String remark) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
		this.comment = comment;
		this.result = result;
		this.dealDate = dealDate;
		this.remark = remark;
	}

	@Override
	public String toString() {
		 StringBuilder sb = new StringBuilder();
	        sb.append(getClass().getSimpleName());
	        sb.append("[");
	        sb.append("Hash=").append(hashCode());
	        sb.append(",id=").append(id);
	        sb.append(", startTime=").append(startTime);
	        sb.append(", endTime=").append(endTime);
	        sb.append(", comment=").append(comment);
	        sb.append(", result=").append(result);
	        sb.append(", dealDate=").append(dealDate);
	        sb.append(", remark=").append(remark);
	        sb.append(", serialVersionUID=").append(serialVersionUID);
	        sb.append("]");
	        return sb.toString();
	}

	
    
  

}
