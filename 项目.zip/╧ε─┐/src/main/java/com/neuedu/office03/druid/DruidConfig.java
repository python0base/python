package com.neuedu.office03.druid;

import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.aop.support.JdkRegexpMethodPointcut;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.alibaba.druid.support.spring.stat.DruidStatInterceptor;

/**
 * DruidStatInterceptor类为druid提供的拦截器
 * JdkRegexpMethodPointcut为使用正则表达式配置切点
 * DefaultPointcutAdvisor类定义advice及 pointcut 属性
 * advice指定使用的通知方式，也就是druid提供的DruidStatInterceptor类，pointcut指定切入点。
 *
 */
@Configuration
public class DruidConfig {
	@Bean
	public DruidStatInterceptor druidStatInterceptor() {
		DruidStatInterceptor dsInterceptor = new DruidStatInterceptor();
		return dsInterceptor;
	}
	
	@Bean
	@Scope("prototype")
	public JdkRegexpMethodPointcut druidStatPointcut() {
		JdkRegexpMethodPointcut pointcut = new JdkRegexpMethodPointcut();
		//pointcut.setPattern("com.jdbc.dao.*");
		pointcut.setPattern("com.neuedu.office03.dao.*");
		return pointcut;
	}
	
	@Bean
	public DefaultPointcutAdvisor druidStatAdvisor(DruidStatInterceptor druidStatInterceptor, JdkRegexpMethodPointcut druidStatPointcut) {
		DefaultPointcutAdvisor defaultPointAdvisor = new DefaultPointcutAdvisor();
		defaultPointAdvisor.setPointcut(druidStatPointcut);
		defaultPointAdvisor.setAdvice(druidStatInterceptor);
		return defaultPointAdvisor;
	}
}