package com.neuedu.office03.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;
import com.neuedu.office03.bll.impl.DepartmentBLL;
import com.neuedu.office03.bll.impl.ManagementService;
import com.neuedu.office03.model.Department;
import com.neuedu.office03.model.Management;

@Controller
public class ManagementController {
	@Autowired
	private ManagementService managementService;
	
	@GetMapping(value = {"login"})
	public String login() {
		return "login1";
	}
	
	@GetMapping(value = {"login1"})
	public String login1() {
		return "login1";
	}	
	
	@GetMapping(value = {"index2"})
	public String inde() {
		return "index2";
	}	
	
	
	@PostMapping(value = {"checklogin"})
	@ResponseBody
	public ResultBean<String> checklogin(String name,String password,HttpSession session) {
		boolean flag = managementService.login(name, password);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("登录成功~~~");
			//通过读取数据库，获取登录用户的详细信息：保护敏感数据
			Management management = new Management();
			management.setName(name);
			//存储在session中
			session.setAttribute("management", management);
		}else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("用户名或密码错误，登录失败~~~");
			session.removeAttribute("management");
		}
		return resultBean;
	}
	
	@GetMapping(value = {"exit"})
	public String exit(HttpSession session) {
		session.removeAttribute("management");
		return "login1";
	}	
}