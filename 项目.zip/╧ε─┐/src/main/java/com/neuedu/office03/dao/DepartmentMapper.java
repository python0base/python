package com.neuedu.office03.dao;

import com.neuedu.office03.model.Department;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.DeleteProvider;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.InsertProvider;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectProvider;
import org.apache.ibatis.annotations.Update;
import org.apache.ibatis.annotations.UpdateProvider;
import org.apache.ibatis.type.JdbcType;

/**
 * 部门信息Mybatis Mapper接口：针对数据库中表department的操作行为定义
 *
 */
@Mapper
public interface DepartmentMapper {
    @Delete({
        "delete from department",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int deleteByPrimaryKey(Integer id);

    @Insert({
        "insert into department (id, name, ",
        "type, telephone, ",
        "fax, description, ",
        "predepartment, date)",
        "values (#{id,jdbcType=INTEGER}, #{name,jdbcType=VARCHAR}, ",
        "#{type,jdbcType=VARCHAR}, #{telephone,jdbcType=VARCHAR}, ",
        "#{fax,jdbcType=VARCHAR}, #{description,jdbcType=VARCHAR}, ",
        "#{predepartment,jdbcType=VARCHAR}, #{date,jdbcType=DATE})"
    })
    int insert(Department record);

  //  @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
 //   int insertSelective(Department record);

    @Select({
        "select",
        "id, name, type, telephone, fax, description, predepartment, date",
        "from department",
        "where id = #{id,jdbcType=INTEGER}"
    })
    @Results({
        @Result(column="id", property="id", jdbcType=JdbcType.INTEGER, id=true),
        @Result(column="name", property="name", jdbcType=JdbcType.VARCHAR),
        @Result(column="type", property="type", jdbcType=JdbcType.VARCHAR),
        @Result(column="telephone", property="telephone", jdbcType=JdbcType.VARCHAR),
        @Result(column="fax", property="fax", jdbcType=JdbcType.VARCHAR),
        @Result(column="description", property="description", jdbcType=JdbcType.VARCHAR),
        @Result(column="predepartment", property="predepartment", jdbcType=JdbcType.VARCHAR),
        @Result(column="date", property="date", jdbcType=JdbcType.DATE)
    })
    Department selectByPrimaryKey(Integer id);

    @UpdateProvider(type=DepartmentSqlProvider.class, method="updateByPrimaryKeySelective")
    int updateByPrimaryKeySelective(Department record);

    @Update({
        "update department",
        "set name = #{name,jdbcType=VARCHAR},",
          "type = #{type,jdbcType=VARCHAR},",
          "telephone = #{telephone,jdbcType=VARCHAR},",
          "fax = #{fax,jdbcType=VARCHAR},",
          "description = #{description,jdbcType=VARCHAR},",
          "predepartment = #{predepartment,jdbcType=VARCHAR},",
          "date = #{date,jdbcType=DATE}",
        "where id = #{id,jdbcType=INTEGER}"
    })
    int updateByPrimaryKey(Department record);
    //查询
    @Select("select id, name, type, telephone, fax, description, predepartment, date  from department")
    List<Department> selectAll();
    //模糊查询
    @SelectProvider(type = DepartmentSqlProvider.class,method = "selectByLike")
    List<Department> selectByLike(@Param("id")Integer id, @Param("name")String name,@Param("type")String type);
    
    //配置自动增长列的值，返回给调用者对象record，因为是引用类型，指向同一个内存区域，所说此处修改时，实参也必须同时变化
    @InsertProvider(type=DepartmentSqlProvider.class, method="insertSelective")
    @Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
     int insertSelective(Department record);
    
    @DeleteProvider(type = DepartmentSqlProvider.class,method = "batchDelete")
    int batchDelete(Integer[] ids);
}