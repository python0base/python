package com.neuedu.office03.dao;

import com.neuedu.office03.model.Department;
import com.neuedu.office03.model.Management;

import java.util.Map;

import org.apache.ibatis.jdbc.SQL;

/**
 * SQL语句：比较复杂的SQL语句，可以将SQL语句集中化管理
 *
 */
public class ManagementSqlProvider {

    public String insertSelective(Management record) {
        SQL sql = new SQL();
        sql.INSERT_INTO("management");
        
        if (record.getId() != null) {
            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
        }
        
        if (record.getPassword() != null) {
            sql.VALUES("password", "#{password,jdbcType=VARCHAR}");
        }
        
        if (record.getName() != null) {
            sql.VALUES("name", "#{name,jdbcType=VARCHAR}");
        }
        
        return sql.toString();
    }

    public String updateByPrimaryKeySelective(Management record) {
        SQL sql = new SQL();
        sql.UPDATE("management");
        
        if (record.getPassword() != null) {
            sql.SET("password = #{password,jdbcType=VARCHAR}");
        }
        
        if (record.getName() != null) {
            sql.SET("name = #{name,jdbcType=VARCHAR}");
        }
        
        sql.WHERE("id = #{id,jdbcType=INTEGER}");
        
        return sql.toString();
    }
}