package com.neuedu.office03.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;

@ControllerAdvice(basePackages= {"com.neuedu.office03","com.neuedu.office03.controller","com.neuedu.office03.bll.impl","com.neuedu.office03.bean","com.neuedu.office03.component"
		,"com.neuedu.office03.dao","com.neuedu.office03.model","com.neuedu.office03.config","com.neuedu.office03.intercepter","com.neuedu.office03.druid"})
public class GlobalExceptionController {
	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public ResultBean<RuntimeException> handleException(RuntimeException ex){
		ResultBean<RuntimeException> resultBean = new ResultBean<RuntimeException> (500,false,ex.getMessage(),ex);
		if(null!=resultBean.getMessage()&&resultBean.getMessage().trim().length()==0) {
			resultBean.setMessage("服务器异常发生，请向管理员反馈");
		}
		
		return resultBean;
	}

}
