package com.neuedu.office03.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import springfox.documentation.annotations.ApiIgnore;
@ApiIgnore//此注解说明此控制器不生成API文档
@Controller
public class IndexController {
@GetMapping(value= {"/","/index"})
public String index() {
	return "index";
}
@GetMapping(value= {"left"})
public String left() {
	return "leftgu";
}


@GetMapping(value= {"content"})
public String content() {
	return "content";
}
}
