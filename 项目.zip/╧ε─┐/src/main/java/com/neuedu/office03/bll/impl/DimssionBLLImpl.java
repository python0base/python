package com.neuedu.office03.bll.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.neuedu.office03.dao.DimissionMapper;
import com.neuedu.office03.model.Dimission;

@Service
public class DimssionBLLImpl implements DimissionBLL{

	@Autowired
	private  DimissionMapper dimissionMapper;
	@Override
	public List<Dimission> selectAll() {
		// TODO Auto-generated method stub
		return dimissionMapper.selectAll();
	}

	@Override
	public List<Dimission> selectByLike(Integer id, String name, Integer type) {
		// TODO Auto-generated method stub
		return dimissionMapper.selectByLike(id, name, type);
	}

	@Override
	public boolean insert(Dimission dimission) {
		// TODO Auto-generated method stub
		int line = dimissionMapper.insertSelective(dimission);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}
	@Transactional(rollbackFor=Exception.class)
	@Override
	public boolean update(Dimission dimission) {
		// TODO Auto-generated method stub
		int line = dimissionMapper.updateByPrimaryKeySelective(dimission);
		// 返回操作是否成功
		return line == 1 ? true : false;
	}

	@Override
	public Dimission selectById(Integer id) {
		// TODO Auto-generated method stub
		return dimissionMapper.selectByPrimaryKey(id);
	}

	@Transactional(isolation = Isolation.DEFAULT,propagation=Propagation.REQUIRED)
	@Override
	public boolean batchDelete(Integer[] ids) {
		// TODO Auto-generated method stub
	    int line = dimissionMapper.batchDelete(ids);
		return line>0?true:false;
	}


}
