package com.neuedu.office03.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.jdbc.SQL;


import com.neuedu.office03.model.Dimission;

public class DimissionSqlProvider {

	  public String insertSelective(Dimission record) {
	        SQL sql = new SQL();
	        sql.INSERT_INTO("dimission");
	        
	        if (record.getId() != null) {
	            sql.VALUES("id", "#{id,jdbcType=INTEGER}");
	        }
	        
	        if (record.getName() != null) {
	            sql.VALUES("name", "#{name,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getInDate() != null) {
	            sql.VALUES("InDate", "#{InDate,jdbcType=DATE}");
	        }
	        
	        if (record.getType() != null) {
	            sql.VALUES("type", "#{type,jdbcType=INTEGER}");
	        }
	        
	        if (record.getDirection() != null) {
	            sql.VALUES("direction", "#{direction,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getToTalents() != null) {
	            sql.VALUES("toTalents", "#{toTalents,jdbcType=INTEGER}");
	        }
	        
	        if (record.getRemark() != null) {
	            sql.VALUES("remark", "#{remark,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getDimissionDepId() != null) {
	            sql.VALUES("dimissionDepId", "#{dimissionDepId,jdbcType=INTEGER}");
	        }
	        
	        if (record.getDimissionStaId() != null) {
	            sql.VALUES("dimissionStaId", "#{dimissionStaId,jdbcType=INTEGER}");
	        }
	        
	        if (record.getGoDate() != null) {
	            sql.VALUES("goDate", "#{goDate,jdbcType=DATE}");
	        }
	        
	        return sql.toString();
	    }

	    public String updateByPrimaryKeySelective(Dimission record) {
	        SQL sql = new SQL();
	        sql.UPDATE("dimission");
	        
	        if (record.getName() != null) {
	            sql.SET("name = #{name,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getInDate() != null) {
	            sql.SET("InDate = #{InDate,jdbcType=DATE}");
	        }
	        
	        if (record.getType() != null) {
	            sql.SET("type = #{type,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getDirection() != null) {
	            sql.SET("direction = #{direction,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getToTalents() != null) {
	            sql.SET("toTalents = #{toTalents,jdbcType=INTEGER}");
	        }
	        
	        if (record.getRemark() != null) {
	            sql.SET("remark = #{remark,jdbcType=VARCHAR}");
	        }
	        
	        if (record.getDimissionDepId() != null) {
	            sql.SET("dimissionDepId = #{dimissionDepId,jdbcType=INTEGER}");
	        }
	        
	        if (record.getDimissionStaId() != null) {
	            sql.SET("dimissionStaId = #{dimissionStaId,jdbcType=INTEGER}");
	        }
	        
	        if (record.getGoDate() != null) {
	            sql.SET("goDate = #{goDate,jdbcType=DATE}");
	        }
	        
	        sql.WHERE("id = #{id,jdbcType=INTEGER}");
	        
	        return sql.toString();
	    }
	    public String selectByLike(Integer id, String name,Integer type) {
			SQL sql = new SQL();
			sql.SELECT("id, name, InDate, type, direction, toTalents, remark, dimissionDepId, dimissionStaId, goDate");
			sql.FROM("dimission");
			sql.WHERE("1=1");
			if (null != id) {
				sql.WHERE("id  like  concat('%', #{id} , '%')");
			}
			if (null != name  && name.trim().length()>0) {
				sql.WHERE("name  like  concat('%', #{name} , '%')");
			}
			if (null != type  ) {
				sql.WHERE("type  like  concat('%', #{type} , '%')");
			}
			return sql.toString();
		}
	   
	    
	    
		public String batchDelete(Map map) {
			Integer[] ids = (Integer[]) map.get("array");//数组是array，集合list是list
			StringBuffer sql = new StringBuffer("delete from dimission   where  id in (");
			for (int i = 0; i < ids.length; i++) {
				if (i == ids.length-1) {
					//最后个数组值
					sql.append(ids[i] + ")");
				}else {
					sql.append(ids[i] + ",");
				}
			}
			return sql.toString();
		}
}
