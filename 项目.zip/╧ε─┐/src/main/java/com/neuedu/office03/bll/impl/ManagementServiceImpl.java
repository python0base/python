package com.neuedu.office03.bll.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.neuedu.office03.dao.ManagementMapper;

@Service
public class ManagementServiceImpl implements ManagementService {
	@Autowired
	private ManagementMapper managementMapper;

	@Override
	public boolean login(String name, String password) {
		int line = managementMapper.login(name, password);
		return line == 1 ?true: false;
	}

}