package com.neuedu.office03.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.neuedu.office03.bean.ResultBean;
import com.neuedu.office03.bll.impl.PostBLL;
import com.neuedu.office03.model.Department;
import com.neuedu.office03.model.Post;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

@Api(tags = "岗位信息控制器")
@Controller
public class PostController {

	@Autowired
	private PostBLL postBLL;
	
	@GetMapping(value = {"/post/managerPost"})
	public String managerDepartments(Model model) {
		//查询所有部门信息
		List<Post> post = postBLL.selectAll();
		//准备统一返回数据类型的对象
		ResultBean<List<Post>> resultBean = new ResultBean<List<Post>>(200, true, "查询所有部门信息成功", post);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/Post/managerPost";
	}
	
	
	@ApiOperation(value = "根据岗位编号、岗位名称、岗位类型实现多条件模糊组合查询")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "id",value = "岗位编号",required = false,dataType = "Integer",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "name",value = "岗位名称",required = false,dataType = "String",defaultValue = "")
			,@ApiImplicitParam(paramType = "query",name = "type",value = "岗位类型",required = false,dataType = "String",defaultValue = "")
	})
	@GetMapping(value = {"/post/selectbylike"})
	public String selectbylike(Integer id,String name,String type,Model model) {
		//多条件组合模糊查询
		List<Post> post = postBLL.selectByLike(id, name, type);
		//准备统一返回数据类型的对象
		ResultBean<List<Post>> resultBean = new ResultBean<List<Post>>(200, true, "查询所有部门信息成功", post);
		//通过Model传递数据
		model.addAttribute("office", resultBean);
		return "/post/managerPost";
	}
	
	/**
	 * 返回增加部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"post/createPost"})
	public String createPost() {
		return "/post/createPost";
	}
	
	/**
	 * 返回修改部门信息的页面
	 * @return
	 */
	@GetMapping(value = {"post/updataPost"})
	public String updataPost(Integer id, Model model) {
		Post post = postBLL.selectById(id);
		ResultBean<Post> resultBean = new ResultBean<Post>(200, true, "查询部门信息成功",post);
		//传递部门实体信息数据
		model.addAttribute("rdata", resultBean);
		return "/post/updataPost";
	}
	
	/*
	 * @InitBinder public void initBinder(WebDataBinder binder) { SimpleDateFormat
	 * dateFormat = new SimpleDateFormat ("yyyy-MM-dd");
	 * 
	 * dateFormat.setLenient(false); binder.registerCustomEditor(Date.class, new
	 * CustomDateEditor(dateFormat,true)); }
	 */
	/**
	 * 返回增加/修改的结果JSON
	 * @param id
	 * @param name
	 * @param type
	 * @param telephone
	 * @param fax
	 * @param description
	 * @param predepartment
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	
	
	@ApiOperation(value = "岗位信息的新增或修改保存操作")
	@ApiImplicitParams(value = {
			@ApiImplicitParam(paramType = "query",name = "department",value = "岗位信息实体对象",required = true)
	})

	@PostMapping(value = {"post/save"})
	@ResponseBody
	public ResultBean<String> save(Post post) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		//department是实参
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, sdf.parse(date));
		//Department department = new Department(id, name, type, telephone, fax, description, predepartment, date);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (null == post.getId()) {
			//增加部门
			if (postBLL.insert(post)) {
				resultBean.setCode(200);
				resultBean.setMessage("增加岗位信息成功！新增的岗位编号是" + post.getId());//获取自动增长列的值
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("增加岗位信息失败！");
			}
		}	else {
			//修改部门
			if (postBLL.update(post)) {
				resultBean.setCode(200);
				resultBean.setMessage("修改岗位信息成功！");
			}else {
				resultBean.setCode(500);
				resultBean.setMessage("修改岗位信息失败！");
			}
		}
		return resultBean;
	}
	
	
	@PostMapping(value = {"post/batchdelete"})
	@ResponseBody
	public ResultBean<String> batchdelete(@RequestParam("ids[]")Integer[] ids) {
		boolean flag = postBLL.batchDelete(ids);
		ResultBean<String> resultBean = new ResultBean<String>();
		if (flag) {
			resultBean.setCode(200);
			resultBean.setSuccessed(true);
			resultBean.setMessage("岗位信息删除成功~~~");
		}else {
			resultBean.setCode(500);
			resultBean.setSuccessed(false);
			resultBean.setMessage("岗位信息删除失败~~~");
		}
		return resultBean;
	}
}
